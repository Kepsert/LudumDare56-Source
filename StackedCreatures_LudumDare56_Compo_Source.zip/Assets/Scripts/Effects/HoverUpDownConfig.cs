using DG.Tweening;
using UnityEngine;

[CreateAssetMenu(fileName = "HoverConfig", menuName = "Effects/HoverConfig", order = 0)]
public class HoverUpDownConfig : ScriptableObject
{
    [SerializeField] float _hoverDistance = 0.25f;
    public float HoverDistance => _hoverDistance;
    [SerializeField] float _hoverDuration = 1.25f;
    public float HoverDuration => _hoverDuration;
    [SerializeField] Ease _ease = Ease.Linear;
    public Ease Ease => _ease;
}
