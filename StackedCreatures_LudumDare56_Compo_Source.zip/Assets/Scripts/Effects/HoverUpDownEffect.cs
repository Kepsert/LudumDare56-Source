using DG.Tweening;
using UnityEngine;

public class HoverUpDownEffect : MonoBehaviour
{
    [SerializeField] HoverUpDownConfig _config;

    Sequence _pulse;

    void Awake()
    {
        _pulse = DOTween.Sequence();
        Vector3 origPos = this.transform.localPosition;
        Vector3 targetPos = this.transform.localPosition + new Vector3(0, _config.HoverDistance, 0);
        _pulse.Append(this.transform.DOLocalMove(targetPos, _config.HoverDuration).SetEase(_config.Ease));
        _pulse.Append(this.transform.DOLocalMove(origPos, _config.HoverDuration).SetEase(_config.Ease));
        _pulse.SetLoops(-1);
    }

    public void KillSequence()
    {
        _pulse.Kill();
    }

    public void StartSequence()
    {
        if (!_pulse.IsActive() && !_pulse.IsPlaying())
            _pulse.Restart();
    }

    void OnDestroy()
    {
        _pulse.Kill();
    }
}
