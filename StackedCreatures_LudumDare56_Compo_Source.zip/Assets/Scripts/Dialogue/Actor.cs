using UnityEngine;

public class Actor : MonoBehaviour
{
    [SerializeField] string _actorName = null;
    [SerializeField] Animator _animator = null;
    public Animator Animator => _animator;

    DialogueService _dialogueService;

    public virtual void OnEnable()
    {
        if (_dialogueService == null)
            _dialogueService = ServiceLocator.GetService<DialogueService>();

        _dialogueService.RegisterActor(_actorName, _animator);
    }

    public virtual void OnDisable()
    {
        if (_dialogueService == null)
            _dialogueService = ServiceLocator.GetService<DialogueService>();

        _dialogueService.UnregisterActor(_actorName);
    }

    public virtual void PlayActorAnimation(string animationName)
    {
        _animator.Play(animationName);
    }
}
