using UnityEngine;

public class FinishTrigger : MonoBehaviour, IInteractable, ITriggerable
{
    [SerializeField] InteractableType _type = InteractableType.FinishTrigger;
    [SerializeField] Transform _gemPosition = null;
    [SerializeField] Finish _finish = null;
    [SerializeField] Collider2D _trigger = null;
    public InteractableType InteractableType => _type;

    public Transform GetTransform()
    {
        return _gemPosition;
    }

    public ITriggerable GetTrigger()
    {
        return _finish;
    }

    public void Interact(Transform transform = null)
    {
        _trigger.enabled = false;
    }

    public void Trigger()
    {
        return;
    }
}
