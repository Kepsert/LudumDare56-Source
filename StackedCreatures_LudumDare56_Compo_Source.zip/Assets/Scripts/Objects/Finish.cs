using UnityEngine;

public class Finish : MonoBehaviour, ITriggerable, IInteractable
{
    [SerializeField] InteractableType _type = InteractableType.Finish;
    [SerializeField] Animator _animator = null;
    [SerializeField] Collider2D _playerTrigger = null;
    [SerializeField] Transform _gemPosition = null;
    [SerializeField] ParticleSystem _starsParticles = null;
    [SerializeField] Transform _middlePoint = null;

    AudioService AudioService;

    bool _open;

    public Transform GemPosition => _gemPosition;

    public InteractableType InteractableType => _type;

    public Transform GetTransform()
    {
        return _middlePoint;
    }

    public ITriggerable GetTrigger()
    {
        return null;
    }

    public void Interact(Transform transform = null)
    {
        throw new System.NotImplementedException();
    }

    public void Trigger()
    {
        if (!_open)
        {
            _open = true;
            AudioService ??= ServiceLocator.GetService<AudioService>();

            AudioService.PlaySfxSound("DoorOpen", AudioType.Sfx);
            _starsParticles.gameObject.SetActive(true);
            _animator.Play("Active");
            _playerTrigger.enabled = true;
        }
    }
}
