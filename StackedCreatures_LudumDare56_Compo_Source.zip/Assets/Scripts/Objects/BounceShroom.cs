using UnityEngine;

public class BounceShroom : MonoBehaviour, IInteractable, IDeinteractable
{
    [SerializeField] InteractableType _type = InteractableType.BounceShroom;
    [SerializeField] Animator _anim = null;
    [SerializeField] Collider2D _bounceCollider = null;

    AudioService AudioService;

    public InteractableType InteractableType => _type;

    void Awake()
    {
        AudioService ??= ServiceLocator.GetService<AudioService>();
    }

    public void Deinteract(Transform transform = null)
    {
        _bounceCollider.enabled = false;
    }

    public Transform GetTransform()
    {
        return null;
    }

    public void Interact(Transform transform = null)
    {
        if (!_bounceCollider.enabled)
        {
             AudioService.PlaySfxSound("Bounce", AudioType.Sfx);
        }

        _anim.Play("Active");
        _bounceCollider.enabled = true;
    }
}
