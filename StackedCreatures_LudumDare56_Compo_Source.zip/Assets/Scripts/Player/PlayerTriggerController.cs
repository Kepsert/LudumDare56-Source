using UnityEngine;

public class PlayerTriggerController : MonoBehaviour
{
    AudioService AudioService;

    PlayerStackController _stackController;
    PlayerController _playerController;
    ParentTriggerHandler _parentTriggerHandler;

    void Awake()
    {
        _stackController ??= GetComponentInParent<PlayerStackController>();
        _playerController ??= GetComponentInParent<PlayerController>();
        _parentTriggerHandler ??= GetComponentInParent<ParentTriggerHandler>();

        AudioService ??= ServiceLocator.GetService<AudioService>();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        ICollectable collectable = collision.GetComponent<ICollectable>();
        if (collectable != null)
        {
            switch (collectable.CollectableType)
            {
                case CollectableType.Jimmy:
                    CreatureUpgradeTypes upgradeType = collision.GetComponent<IUpgradeable>().GetUpgradeType();
                    _stackController.AddToStack(upgradeType);
                    collectable.Collect();

                    if (upgradeType.Equals(CreatureUpgradeTypes.None))
                        AudioService.PlaySfxSound("Jimmy", AudioType.Sfx);
                    else if (upgradeType.Equals(CreatureUpgradeTypes.Dash))
                        AudioService.PlaySfxSound("DashJimmy", AudioType.Sfx);
                    else
                        AudioService.PlaySfxSound("WingJimmy", AudioType.Sfx);
                    break;
                case CollectableType.Key:
                    collectable.Collect(_stackController.FollowTarget);
                    AudioService.PlaySfxSound("Gem", AudioType.Sfx);
                    _parentTriggerHandler.SetCurrentUsable(collision.GetComponent<IUsable>());
                    break;
            }
        }

        IInteractable interactable = collision.GetComponent<IInteractable>();
        if (interactable != null)
        {
            switch (interactable.InteractableType)
            {
                case InteractableType.FinishTrigger:
                    if (_parentTriggerHandler.CurrentUsable != null)
                    {
                        ITriggerable triggerable = collision.GetComponent<ITriggerable>().GetTrigger();
                        _parentTriggerHandler.CurrentUsable.Use(interactable.GetTransform(), triggerable);
                        _parentTriggerHandler.SetCurrentUsable(null);
                        interactable.Interact();
                    }
                    break;
                case InteractableType.Finish:
                    AudioService.PlaySfxSound("Finish", AudioType.Sfx);
                    _playerController.PlayerFinished();
                    _stackController.PlayerFinished();
                    break;
            }
        }

        IKiller killer = collision.GetComponent<IKiller>();
        if (killer != null)
        {
            switch (killer.KillerType)
            {
                case KillerType.Spike:
                    _stackController.PlayerDied();
                    break;
            }
        }
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        IInteractable interactable = collision.GetComponent<IInteractable>();
        if (interactable != null)
        {
            InteractableType type = interactable.InteractableType;
            switch (type)
            {
                case InteractableType.BounceShroom:
                    if (_playerController.Falling)
                        interactable.Interact();
                    break;
            }
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        IDeinteractable deinteractable = collision.GetComponent<IDeinteractable>();
        if (deinteractable != null)
        {
            InteractableType type = deinteractable.InteractableType;
            switch (type)
            {
                case InteractableType.BounceShroom:
                    deinteractable.Deinteract();
                    break;
            }

        }
    }
}
