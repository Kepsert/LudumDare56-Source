using UnityEngine;

public class ParentTriggerHandler : MonoBehaviour
{
    IUsable _currentUsable;
    public IUsable CurrentUsable => _currentUsable;

    public void SetCurrentUsable(IUsable usable)
    {
        _currentUsable = usable;
    }
}
