using LDtkUnity;
using Messaging;
using Messaging.Messages;
using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStackController : MonoBehaviour, ILDtkImportedFields
{
    AudioService AudioService;
    InputService InputService;
    LevelManagementService LevelManagementService;
    CameraService CameraService;
    TimerService TimerService;
    UIService UIService;

    [SerializeField] CreatureStackConfig _config = null;
    [SerializeField] GameObject _creaturePrefab = null;
    [SerializeField] List<CreatureController> _creatureStack = new();
    [SerializeField] PlayerController _playerController = null;

    [SerializeField] int _startingStack = 5;

    [SerializeField] Transform _followTarget = null;
    public Transform FollowTarget => _followTarget;

    Guid _deathTimer;

    int _stackCount;
    public int StackCount => _stackCount;

    float _currentOffset = 0;

    void Awake()
    {
        InitServices();
        SubscribeToEvents();
    }

    void InitServices()
    {
        InputService ??= ServiceLocator.GetService<InputService>();
        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();
        CameraService ??= ServiceLocator.GetService<CameraService>();
        TimerService ??= ServiceLocator.GetService<TimerService>();
        UIService ??= ServiceLocator.GetService<UIService>();
        AudioService ??= ServiceLocator.GetService<AudioService>();
    }

    void SubscribeToEvents()
    {
        InputService.OnRestartPressed += PlayerDied;
        InputService.OnPausePressed += OnPausePressed;

        MessageHub.Subscribe<RestartLevelMessage>(this, OnLevelRestartMessage);
    }

    void OnDestroy()
    {
        InputService.OnRestartPressed -= PlayerDied;
        InputService.OnPausePressed -= OnPausePressed;

        MessageHub.Unsubscribe<RestartLevelMessage>(this);
    }

    void Start()
    {
        Init();
    }

    void Init()
    {
        _stackCount = _creatureStack.Count;

        CreateStack();
    }

    void CreateStack()
    {
        _creatureStack.Clear();

        for (int i = 0; i < _startingStack; i++)
        {
            AddToStack();
        }

        CameraService.FollowNewTarget(_creatureStack[0].transform);
        _playerController.SetGroundChecks(_creatureStack[0].GetGroundChecks());
        _playerController.ToggleRbKinematic(false);
        _creatureStack[0].SetIsBottomCreature();
    }

    public void AddToStack(CreatureUpgradeTypes upgradeType = CreatureUpgradeTypes.None)
    {
        _stackCount++;
        _currentOffset += _config.StackOffset;
        Vector3 startPosition = new Vector3(transform.position.x, transform.position.y + _currentOffset, transform.position.z);
        GameObject creature = Instantiate(_creaturePrefab, startPosition, Quaternion.identity, transform);
        CreatureController creatureController = creature.GetComponent<CreatureController>();
        creatureController.AddToStack(upgradeType);
        _creatureStack.Add(creatureController);
        _creatureStack[0].ToggleLastJimmyInStack(false);

        SetFollowTransformPosition();

        if (_deathTimer != null)
            TimerService.RemoveTimer(_deathTimer);
    }

    public CreatureUpgradeTypes RemoveFromStack()
    {
        if (_stackCount > 1)
        {
            _stackCount--;
            _creatureStack[0].RemoveFromStack();
            _creatureStack.RemoveAt(0);
            _playerController.SetGroundChecks(_creatureStack[0].GetGroundChecks());
            _creatureStack[0].SetIsBottomCreature();
            CameraService.FollowNewTarget(_creatureStack[0].transform);

            SetFollowTransformPosition();

            if (_stackCount == 1)
            {
                _creatureStack[0].ToggleLastJimmyInStack(true);
                _deathTimer = TimerService.AddTimer(_config.SingleJimmyLifeTime, () =>
                {
                    PlayerDied();
                });
            }            
        }
        return _creatureStack[0].UpgradeType;
    }

    public CreatureUpgradeTypes GetBottomUpgradeType()
    {
        return _creatureStack[0].UpgradeType;
    }

    public void PlayerFinished()
    {
        _creatureStack[0].ToggleLastJimmyInStack(false);
        TimerService.RemoveTimer(_deathTimer);
        LevelManagementService.LoadNextLevel(1.25f);
    }

    public void PlayerDied()
    {
        AudioService.PlaySfxSound("Death", AudioType.Sfx);
        _creatureStack[0].ToggleLastJimmyInStack(false);
        TimerService.RemoveTimer(_deathTimer);
        _playerController.PlayerDied();
        LevelManagementService.RestartLevel(_config.DeathAnimDuration);
    }

    void SetFollowTransformPosition()
    {
        _followTarget.position = new Vector3(_followTarget.position.x, (_creatureStack[0].transform.position.y + 1) + (_stackCount / 2), transform.position.z);
    }

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _startingStack = fields.GetInt("StartingStack");
    }

    void OnPausePressed()
    {
        Time.timeScale = 0;
        UIService.ShowScreen("PauseScreen");
    }

    void OnLevelRestartMessage(RestartLevelMessage message)
    {
        PlayerDied();
    }

    public Transform GetBottomStackTransform()
    {
        return _creatureStack[0].transform;
    }
}
