using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "CreatureUpgrade", menuName = "Player/CreatureUpgrade", order = 0)]
public class CreatureUpgradeConfig : ScriptableObject
{
    [SerializeField] List<CreatureUpgrades> _creatureUpgradesList = new();
    public List<CreatureUpgrades> CreatureUpgradesList => _creatureUpgradesList;

    Dictionary<CreatureUpgradeTypes, GameObject> _dictionaryUpgradePrefabByType = new();

    public GameObject GetUpgradePrefabByType(CreatureUpgradeTypes type)
    {
        if (_dictionaryUpgradePrefabByType.Count == 0)
            foreach (CreatureUpgrades upgrade in _creatureUpgradesList)
                if (!_dictionaryUpgradePrefabByType.ContainsKey(upgrade.UpgradeType))
                    _dictionaryUpgradePrefabByType.TryAdd(upgrade.UpgradeType, upgrade.UpgradePrefab);

        return _dictionaryUpgradePrefabByType[type];
    }
}

[System.Serializable]
public class CreatureUpgrades
{
    public CreatureUpgradeTypes UpgradeType;
    public GameObject UpgradePrefab;
}

public enum CreatureUpgradeTypes
{
    None = 0,
    Dash = 1,
    Wings = 2,
}
