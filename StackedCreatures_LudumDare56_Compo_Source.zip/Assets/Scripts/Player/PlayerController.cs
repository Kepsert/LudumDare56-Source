using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    AudioService AudioService;
    InputService InputService;
    EffectService EffectService;

    [Header("Config")]
    [SerializeField] PlayerData _data = null;

    [Space(15)]
    [Header("Refs")]
    [SerializeField] Rigidbody2D _rb = null;
    [SerializeField] List<Transform> _groundCheckList = new();
    [SerializeField] PlayerStackController _stackController = null;

    public event Action OnPlayerDied;

    bool _hasControl = true;
    bool _jump;
    bool _jumpReleased;
    bool _jumpPressed;
    float _jumpBufferTimer;
    float _jumpTimer;
    float _coyoteJumpTimer;

    bool _dash;
    bool _dashPressed;
    bool _dashReleased;
    float _dashTimer;

    float _horizontalMovement;
    public float HorizontalMovement => _horizontalMovement;
    float _verticalMovement;
    public float VerticalMovement => _verticalMovement;

    bool _isGrounded;
    public bool IsGrounded => _isGrounded;

    bool _facingRight = true;
    public bool FacingRight => _facingRight;

    bool _hasDied;
    public bool HasDied => _hasDied;

    bool _hasFinished;
    public bool HasFinished => _hasFinished;

    bool _falling;
    public bool Falling => _falling;

    Transform _respawnPoint;

    float _jumpModifier = 1;

    void Awake()
    {
        InitRefs();
        InitServices();

        InputService.SwitchActionMap(InputMapType.Gameplay);
    }

    void InitRefs()
    {
        _rb ??= GetComponent<Rigidbody2D>();
    }

    void InitServices()
    {
        AudioService ??= ServiceLocator.GetService<AudioService>();
        InputService ??= ServiceLocator.GetService<InputService>();
        EffectService ??= ServiceLocator.GetService<EffectService>();
    }

    void Start()
    {
        SubscribeToEvents();
    }

    void SubscribeToEvents()
    {
        InputService.OnJumpPressed += OnJumpPressed;
        InputService.OnJumpReleased += OnJumpReleased;
    }

    void OnDestroy()
    {
        InputService.OnJumpPressed -= OnJumpPressed;
        InputService.OnJumpReleased -= OnJumpReleased;
    }

    void FixedUpdate()
    {
        CalculateIsGrounded();
        CheckJumpBuffer();
        HandleDash();

        if (_hasControl)
            Move();

        SetFacingDirection();
    }

    void Move()
    {
        _horizontalMovement = (!_dash) ? InputService.HorizontalInput : (_facingRight) ? _data.DashForce : -_data.DashForce;
        _rb.velocity = new Vector2((_horizontalMovement * _data.MovementSpeed), GetVerticalVelocity());
    }

    float GetVerticalVelocity()
    {
        if (_jump)
        {
            _jumpTimer += Time.deltaTime;

            _verticalMovement = (!_jumpReleased) ? _data.JumpForce * _jumpModifier : _data.JumpForce * 0.5f * _jumpModifier;
            _coyoteJumpTimer = 1;
            if (_jumpTimer > _data.JumpDuration)
                _jump = false;
        }
        else if (_dash)
            _verticalMovement = 0;
        else
            _verticalMovement = Mathf.Clamp(_rb.velocity.y, (!_stackController.GetBottomUpgradeType().Equals(CreatureUpgradeTypes.Wings)) ? _data.MaxFallSpeed : _data.MaxFallSpeed * 0.65f, 50);

        if (_verticalMovement < -0.65f)
            _falling = true;
        else
            _falling = false;

        return _verticalMovement;
    }

    void HandleDash()
    {
        if (_dash)
        {
            _dashTimer += Time.deltaTime;

            if (_dashTimer >= _data.DashDuration)
            {
                _dashTimer = 0;
                _dash = false;
            }
        }
    }

    void CalculateIsGrounded()
    {
        _isGrounded = false;

        if (_rb.velocity.y <= 0.15f)
        {
            if (_groundCheckList != null)
            {
                foreach (Transform groundCheck in _groundCheckList)
                {
                    Collider2D[] colliders = Physics2D.OverlapCircleAll(groundCheck.position, _data.GroundRadius, _data.WhatIsGround);
                    for (int i = 0; i < colliders.Length; i++)
                        if (colliders[i].gameObject != gameObject)
                        {
                            _coyoteJumpTimer = 0;
                            _isGrounded = true;
                            return;
                        }
                }
            }
        }
        _coyoteJumpTimer += Time.deltaTime;
    }

    void CheckJumpBuffer()
    {
        if (_jumpPressed)
        {
            _jumpBufferTimer += Time.deltaTime;
            if (_jumpBufferTimer <= _data.JumpBufferTime && !_jumpReleased)
                OnJumpPressed();
            else if (_jumpBufferTimer <= _data.JumpBufferTime && _jumpReleased)
                OnJumpReleased();
            else
                _jumpPressed = false;
        }
    }

    void OnJumpPressed()
    {
        if ((_isGrounded || CheckHasCoyoteJumpTime()) && !_jump && _hasControl)
        {
            _jumpPressed = false;
            _jumpReleased = false;
            _jumpTimer = 0;
            _jump = true;

            if (_stackController.GetBottomUpgradeType() is not CreatureUpgradeTypes.Wings)
            {
                AudioService.PlaySfxSound("Jump", AudioType.Sfx);
                _jumpModifier = 1f - (0.05f * _stackController.StackCount);
            }
            else
            {
                AudioService.PlaySfxSound("JumpWings", AudioType.Sfx);
                _jumpModifier = 1.35f + (0.025f * _stackController.StackCount);
            }
        }
        else if ((!_isGrounded && !CheckHasCoyoteJumpTime() && _stackController.StackCount > 1) && !_jump && _hasControl)
        {
            CreatureUpgradeTypes upgradeTypes = _stackController.GetBottomUpgradeType();

            _stackController.RemoveFromStack();

            switch (upgradeTypes)
            {
                case CreatureUpgradeTypes.None:
                    AudioService.PlaySfxSound("Jump", AudioType.Sfx);
                    _jumpPressed = false;
                    _jumpReleased = false;
                    _jumpTimer = 0;
                    _jump = true;
                    _jumpModifier = 1f - (0.05f * _stackController.StackCount);
                    EffectService.PlayEffect("JumpDust", _stackController.GetBottomStackTransform().position, scale: FacingRight ? new Vector3(1, 1, 1) : new Vector3(-1, 1, 1));
                    break;
                case CreatureUpgradeTypes.Dash:
                    AudioService.PlaySfxSound("Dash", AudioType.Sfx);
                    _dashPressed = false;
                    _dashReleased = false;
                    _dashTimer = 0;
                    _dash = true;
                    break;
                case CreatureUpgradeTypes.Wings:
                    _jumpPressed = false;
                    _jumpReleased = false;
                    _jumpTimer = 0;
                    _jump = true;
                    AudioService.PlaySfxSound("JumpWings", AudioType.Sfx);
                    _jumpModifier = 1.35f + (0.025f * _stackController.StackCount);
                    EffectService.PlayEffect("JumpDust", _stackController.GetBottomStackTransform().position, scale: FacingRight ? new Vector3(1, 1, 1) : new Vector3(-1, 1, 1));
                    break;
            }
        }
        else if (!_jumpPressed)
        {
            _jumpBufferTimer = 0;
            _jumpPressed = true;
            _jumpReleased = false;
        }
    }

    bool CheckHasCoyoteJumpTime()
    {
        if (_coyoteJumpTimer <= _data.CoyoteJumpTime)
            return true;
        return false;
    }

    void OnJumpReleased()
    {
        _jumpReleased = true;
        float jumpTimeLeft = _data.JumpDuration - _jumpTimer;
        _jumpTimer += jumpTimeLeft * 0.5f;
    }

    void SetFacingDirection()
    {
        if (_horizontalMovement > 0 && !_facingRight)
            FlipCharacter();
        else if (_horizontalMovement < 0 && _facingRight)
            FlipCharacter();
    }

    void FlipCharacter()
    {
        _facingRight = !_facingRight;
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }

    public void SetGroundChecks(List<Transform> groundChecks)
    {
        _groundCheckList = new(groundChecks);
    }

    public void ToggleRbKinematic(bool toggle)
    {
        _rb.isKinematic = toggle;
    }

    public void PlayerDied()
    {
        _hasControl = false;
        _hasDied = true;
        if (_rb != null)
        {
            _rb.velocity = Vector2.zero;
            _rb.isKinematic = true;
        }
    }

    public void PlayerFinished()
    {
        if (!_hasFinished)
        {
            _hasControl = false;
            _hasFinished = true;
            _rb.velocity = Vector2.zero;
        }
    }
}
