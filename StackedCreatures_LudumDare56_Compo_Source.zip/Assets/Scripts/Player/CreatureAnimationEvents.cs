using UnityEngine;

public class CreatureAnimationEvents : MonoBehaviour
{
    EffectService EffectService;

    PlayerController _playerController;

    void Awake()
    {
        InitServices();
    }

    void InitServices()
    {
        EffectService ??= ServiceLocator.GetService<EffectService>();
    }

    public void InjectPlayerController(PlayerController controller)
    {
        _playerController = controller;
    }

    public void PlayEffect(string name)
    {
        Vector3 scale = Vector3.one;
        if (_playerController != null)
            if (!_playerController.FacingRight)
                scale = new Vector3(-1, 1, 1);
        EffectService.PlayEffect(name, this.transform.position, scale: scale);
    }
}
