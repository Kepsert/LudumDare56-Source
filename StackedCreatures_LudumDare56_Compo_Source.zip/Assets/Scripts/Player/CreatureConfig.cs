using UnityEngine;

[CreateAssetMenu(fileName = "CreatureConfig", menuName = "Player/CreatureConfig", order = 0)]
public class CreatureConfig : ScriptableObject
{
    [SerializeField] LayerMask _whatIsGround;
    public LayerMask WhatIsGround => _whatIsGround;
    [SerializeField] float _groundRadius = 0.115f;
    public float GroundRadius => _groundRadius;
    [SerializeField] float _gravity = 7.5f;
    public float Gravity => _gravity;
}
