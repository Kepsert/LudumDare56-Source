using UnityEngine;

[CreateAssetMenu(fileName = "PlayerData", menuName = "Player/PlayerData", order = 0)]
public class PlayerData : ScriptableObject
{
    [Header("Movement")]
    [SerializeField] float _movementSpeed = 5f;
    public float MovementSpeed => _movementSpeed;
    [SerializeField] float _maxFallSpeed = 15f;
    public float MaxFallSpeed => _maxFallSpeed;
    [SerializeField] float _jumpForce = 10;
    public float JumpForce => _jumpForce;
    [SerializeField] float _jumpDuration = 0.2f;
    public float JumpDuration => _jumpDuration;
    [SerializeField] float _jumpBufferTime = 0.075f;
    public float JumpBufferTime => _jumpBufferTime;

    [Space(10)]
    [Header("Dash")]
    [SerializeField] float _dashForce;
    public float DashForce => _dashForce;
    [SerializeField] float _dashDuration;
    public float DashDuration => _dashDuration;

    [Space(10)]
    [Header("Ground")]
    [SerializeField] float _groundRadius = .1f;
    public float GroundRadius => _groundRadius;
    [SerializeField] LayerMask _whatIsGround;
    public LayerMask WhatIsGround => _whatIsGround;
    [SerializeField] float _coyoteJumpTime = 0.125f;
    public float CoyoteJumpTime => _coyoteJumpTime;

    [Space(10)]
    [Header("Animations")]
    [SerializeField] float _deathAnimDuration = 0.9f;
    public float DeathAnimDuration => _deathAnimDuration;
}
