using UnityEngine;

[CreateAssetMenu(fileName = "CreatureStackConfig", menuName = "Player/CreatureStackConfig", order = 0)]
public class CreatureStackConfig : ScriptableObject
{
    [SerializeField] float _stackOffset = 2;
    public float StackOffset => _stackOffset;
    [SerializeField] int _startStackSize = 5;
    public int StartStackSize => _startStackSize;
    [SerializeField] float _singleJimmyLifeTime = 5f;
    public float SingleJimmyLifeTime => _singleJimmyLifeTime;
    [SerializeField] float _deathAnimDuration = 0.6f;
    public float DeathAnimDuration => _deathAnimDuration;
}
