using System.Collections.Generic;
using UnityEngine;

public class CreatureController : MonoBehaviour
{
    [SerializeField] CreatureConfig _config = null;

    [SerializeField] CreatureUpgradeConfig _updateConfig = null;

    [SerializeField] List<Transform> _groundChecks = new();
    [SerializeField] Collider2D _playerCollider = null;
    [SerializeField] Collider2D _groundCollider = null;

    [SerializeField] GameObject _groundColliderObject = null;

    [SerializeField] SpriteRenderer _countdownSpriteRenderer = null;
    [SerializeField] Animator _countdownAnimator = null;
    [SerializeField] Transform _countdownTransform = null;

    CreatureUpgradeTypes _upgradeType;
    public CreatureUpgradeTypes UpgradeType => _upgradeType;

    bool _isGrounded;
    float _fallSpeed = -5;
    Vector3 _targetPosition;

    bool _isBottomCreature;
    public bool IsBottomCreature => _isBottomCreature;

    bool _droppedFromStack;
    public bool DroppedFromStack => _droppedFromStack;

    bool _isPartOfStack;
    public bool IsPartOfStack => _isPartOfStack;

    void Awake()
    {
        _countdownTransform.SetParent(null);
    }

    public List<Transform> GetGroundChecks()
    {
        return _groundChecks;
    }

    public void SetIsBottomCreature()
    {
        _isBottomCreature = true;
    }

    public void AddToStack(CreatureUpgradeTypes upgradeType = CreatureUpgradeTypes.None)
    {
        _isPartOfStack = true;

        _upgradeType = upgradeType;

        if (upgradeType != CreatureUpgradeTypes.None)
            Instantiate(_updateConfig.GetUpgradePrefabByType(upgradeType), this.transform.position, Quaternion.identity, this.transform);
    }

    public void RemoveFromStack()
    {
        _playerCollider.enabled = false;
        _groundCollider.enabled = true;
        _isBottomCreature = false;
        _isPartOfStack = false;
        _droppedFromStack = true;
        transform.SetParent(null);
    }

    void FixedUpdate()
    {
        if (!_isPartOfStack && !_isGrounded && _upgradeType is not CreatureUpgradeTypes.Wings)
        {
            CalculateIsGrounded();

            _fallSpeed += _config.Gravity * Time.deltaTime;

            _targetPosition = new Vector3(transform.position.x, transform.position.y + _fallSpeed * Time.deltaTime, transform.position.z);

            transform.position = Vector3.MoveTowards(transform.position, _targetPosition, Mathf.Abs(_fallSpeed) * Time.deltaTime);

            if (_isGrounded)
                _fallSpeed = 0;
        }

        if (_isPartOfStack)
            _countdownTransform.position = transform.position;
    }

    void CalculateIsGrounded()
    {
        _isGrounded = false;

        if (_groundChecks != null)
        {
            foreach (Transform groundCheck in _groundChecks)
            {
                Collider2D[] colliders = Physics2D.OverlapCircleAll(groundCheck.position, _config.GroundRadius, _config.WhatIsGround);
                for (int i = 0; i < colliders.Length; i++)
                    if (colliders[i].gameObject != gameObject && colliders[i].gameObject != _groundColliderObject)
                    {
                        _isGrounded = true;
                        return;
                    }
            }
        }
    }

    public void ToggleLastJimmyInStack(bool toggle)
    {
        if (toggle)
        {
            _countdownSpriteRenderer.enabled = true;
            _countdownAnimator.Play("Active");
        }
        else
        {
            _countdownSpriteRenderer.enabled = false;
            _countdownAnimator.Play("Idle");
        }
    }
}
