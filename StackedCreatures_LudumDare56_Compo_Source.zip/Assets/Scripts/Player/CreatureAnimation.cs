using UnityEngine;

public class CreatureAnimation : MonoBehaviour
{
    [SerializeField] Animator _animator = null;
    [SerializeField] PlayerController _playerController = null;
    [SerializeField] CreatureAnimationEvents _animationEvents = null;
    [SerializeField] CreatureController _creatureController = null;

    EffectService EffectService;

    float _idleTimer;

    bool _isFalling;

    private void Awake()
    {
        _animator ??= GetComponentInChildren<Animator>();
        _playerController ??= GetComponentInParent<PlayerController>();

        EffectService ??= ServiceLocator.GetService<EffectService>();

        _animationEvents.InjectPlayerController(_playerController);
    }

    void Update()
    {
        if (!_creatureController.DroppedFromStack && _creatureController.IsPartOfStack)
            UpdateAnimationState();
        else
            _animator.Play("Unstacked");
    }

    void UpdateAnimationState()
    {
        float horizontalSpeed = Mathf.Abs(_playerController.HorizontalMovement);

        if (_playerController.HasDied)
        {
            _animator.Play("Death");
            return;
        }
        else if (_playerController.HasFinished)
        {
            _animator.Play("Dance");
        }
        else if (_playerController.IsGrounded)
        {
            if (horizontalSpeed != 0)
            {
                if (_isFalling)
                {
                    if (_creatureController.IsBottomCreature)
                        EffectService.PlayEffect("LandDust", this.transform.position, scale: _playerController.FacingRight ? new Vector3(1, 1, 1) : new Vector3(-1, 1, 1));
                    _isFalling = false;
                }
                if (_creatureController.IsBottomCreature)
                    _animator.Play("Walk");
                _idleTimer = 0;
            }
            else
            {
                if (_playerController.HasFinished)
                {
                    _animator.Play("Dance");
                    return;
                }
                _idleTimer += Time.deltaTime;
                if (_idleTimer >= 10)
                {
                    _animator.Play("Dance");
                }
                else
                {
                    if (_isFalling)
                    {
                        if (_creatureController.IsBottomCreature)
                            EffectService.PlayEffect("LandDust", this.transform.position, scale: _playerController.FacingRight ? new Vector3(1, 1, 1) : new Vector3(-1, 1, 1));
                        _isFalling = false;
                    }
                    _animator.Play("Idle");
                }
            }
        }
        else
        {
            _idleTimer = 0;
            if (_playerController.VerticalMovement > 1f)
            {
                if (_creatureController.IsBottomCreature)
                    _animator.Play("Jump");
            }
            else if (_playerController.VerticalMovement < -0.75f)
            {
                _isFalling = true;
                if (_creatureController.IsBottomCreature)
                    _animator.Play("Fall");
            }
        }

        if (!_creatureController.IsBottomCreature && !_playerController.HasFinished)
            if (_playerController.HorizontalMovement != 0)
            {
                _idleTimer = 0;
                _animator.Play("Idle");
            }
    }
}
