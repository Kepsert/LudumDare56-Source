using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputService : MonoBehaviour
{
    PlayerInputActions _inputActions;

    public event Action OnJumpPressed;
    public event Action OnJumpReleased;
    public event Action OnRestartPressed;
    public event Action OnPausePressed;

    public event Action OnNextPalettePressed;

    public event Action UpPressed;
    public event Action DownPressed;
    public event Action LeftPressed;
    public event Action RightPressed;
    public event Action SelectPressed;
    public event Action ExitPressed;

    float _horizontalInput;
    float _verticalInput;
    public float HorizontalInput => _horizontalInput;
    public float VerticalInput => _verticalInput;

    void Awake()
    {
        _inputActions = new PlayerInputActions();

        SwitchActionMap(InputMapType.Gameplay);
    }

    void EnableGameplayInput()
    {
        _inputActions.Player.Enable();

        _inputActions.Player.Movement.performed += OnMovementPerformed;
        _inputActions.Player.Movement.canceled += OnMovementCanceled;
        _inputActions.Player.Jump.performed += OnJumpPerformed;
        _inputActions.Player.Jump.canceled += OnJumpCanceled;
        _inputActions.Player.Restart.performed += OnRestartPerformed;
        _inputActions.Player.Pause.performed += OnPausePerformed;
    }

    void EnableMenuInput()
    {
        _inputActions.Menu.Enable();

        _inputActions.Menu.Up.performed += OnUpPerformed;
        _inputActions.Menu.Down.performed += OnDownPerformed;
        _inputActions.Menu.Left.performed += OnLeftPerformed;
        _inputActions.Menu.Right.performed += OnRightPerformed;
        _inputActions.Menu.Select.performed += OnSelectPerformed;
        _inputActions.Menu.Exit.performed += OnExitPerformed;
    }

    void OnDestroy()
    {
        DisableGameplayInput();
        DisableMenuInput();
    }

    void DisableGameplayInput()
    {
        _inputActions.Player.Disable();

        _inputActions.Player.Movement.performed -= OnMovementPerformed;
        _inputActions.Player.Movement.canceled -= OnMovementCanceled;
        _inputActions.Player.Jump.performed -= OnJumpPerformed;
        _inputActions.Player.Jump.canceled -= OnJumpCanceled;
        _inputActions.Player.Restart.performed -= OnRestartPerformed;
        _inputActions.Player.Pause.performed -= OnPausePerformed;
    }

    void DisableMenuInput()
    {
        _inputActions.Menu.Disable();
    }

    void OnMovementPerformed(InputAction.CallbackContext context)
    {
        CheckMovement(context.ReadValue<Vector2>());
    }

    void OnMovementCanceled(InputAction.CallbackContext context)
    {
        _horizontalInput = 0;
        _verticalInput = 0;
    }

    void CheckMovement(Vector2 input)
    {
        _horizontalInput = 0;
        _verticalInput = 0;

        if (input.x > 0.35f)
            _horizontalInput = 1;
        else if (input.x < -0.35f)
            _horizontalInput = -1;

        if (input.y > 0.35f)
            _verticalInput = 1;
        else if (input.y < -0.35f)
            _verticalInput = -1;
    }

    void OnJumpPerformed(InputAction.CallbackContext context)
    {
        OnJumpPressed?.Invoke();
    }

    void OnJumpCanceled(InputAction.CallbackContext context)
    {
        OnJumpReleased?.Invoke();
    }

    void OnPausePerformed(InputAction.CallbackContext context)
    {
        OnPausePressed?.Invoke();
    }

    void OnRestartPerformed(InputAction.CallbackContext context)
    {
        OnRestartPressed?.Invoke();
    }

    public void SwitchActionMap(InputMapType type)
    {
        switch (type)
        {
            case InputMapType.Gameplay:
                EnableGameplayInput();
                DisableMenuInput();
                break;
            case InputMapType.Menu:
                DisableGameplayInput();
                EnableMenuInput();
                break;
        }
    }

    void OnExitPerformed(InputAction.CallbackContext context)
    {
        ExitPressed?.Invoke();
    }

    void OnSelectPerformed(InputAction.CallbackContext context)
    {
        SelectPressed?.Invoke();
    }

    void OnRightPerformed(InputAction.CallbackContext context)
    {
        RightPressed?.Invoke();
    }

    void OnLeftPerformed(InputAction.CallbackContext context)
    {
        LeftPressed?.Invoke();
    }

    void OnDownPerformed(InputAction.CallbackContext context)
    {
        DownPressed?.Invoke();
    }

    void OnUpPerformed(InputAction.CallbackContext context)
    {
        UpPressed?.Invoke();
    }
}

public enum InputMapType
{
    Gameplay = 0,
    Menu = 1,
}