using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "UIConfig", menuName = "Config/UI", order = 3)]
public class UIConfig : ScriptableObject
{
    [SerializeField] List<UIData> _uiDataList = new();
    public List<UIData> UIDataList => _uiDataList;
    Dictionary<string, GameObject> _dictionaryScreenByName = new();
    public Dictionary<string, GameObject> DictionaryScreenByName => _dictionaryScreenByName;

    public void Init()
    {
        foreach (UIData data in _uiDataList)
        {
            if (!_dictionaryScreenByName.ContainsKey(data.screenName))
                _dictionaryScreenByName.TryAdd(data.screenName, data.screenPrefab);
        }
    }
}

[System.Serializable]
public struct UIData
{
    public string screenName;
    public GameObject screenPrefab;
}
