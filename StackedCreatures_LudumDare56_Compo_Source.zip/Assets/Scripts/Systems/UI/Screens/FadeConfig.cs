using UnityEngine;

[CreateAssetMenu(fileName = "FadeConfig", menuName = "UI/FadeConfig", order = 3)]
public class FadeConfig : ScriptableObject
{
    [SerializeField] float _fadeDuration = 0.65f;
    public float FadeDuration => _fadeDuration;
}
