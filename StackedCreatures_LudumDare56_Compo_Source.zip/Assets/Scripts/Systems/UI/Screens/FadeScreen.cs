using Cysharp.Threading.Tasks;
using System;
using UnityEngine;
using UnityEngine.UI;

public class FadeScreen : View
{
    [SerializeField] FadeConfig _fadeConfig = null;

    [SerializeField] Image _fadeImage = null;

    public override void ShowScreen()
    {
        base.ShowScreen();

        _canvasGroup.blocksRaycasts = false;
    }

    public async UniTask FadeOut(float duration = 0, float targetAlpha = 1)
    {
        if (duration == 0)
            duration = _fadeConfig.FadeDuration;

        float startAlpha = 0;
        float timeElapsed = 0;

        while (timeElapsed < duration)
        {
            timeElapsed += Time.deltaTime;
            float newAlpha = Mathf.Lerp(startAlpha, targetAlpha, timeElapsed / duration);
            SetAlpha(newAlpha);
            await UniTask.Yield();
        }

        SetAlpha(targetAlpha);
    }

    public async UniTask FadeIn(float delayedFadeIn = 0, float duration = 0, float targetAlpha = 0)
    {
        await UniTask.Delay(TimeSpan.FromSeconds(delayedFadeIn));

        if (duration == 0)
            duration = _fadeConfig.FadeDuration;

        float startAlpha = 1;
        float timeElapsed = 0;

        while (timeElapsed < duration)
        {
            timeElapsed += Time.deltaTime;
            float newAlpha = Mathf.Lerp(startAlpha, targetAlpha, timeElapsed / duration);
            SetAlpha(newAlpha);
            await UniTask.Yield();
        }

        SetAlpha(targetAlpha);
    }

    void SetAlpha(float alpha)
    {
        Color color = _fadeImage.color;
        color.a = alpha;
        _fadeImage.color = color;
    }
}
