using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OptionsScreen : View
{
    PaletteService PaletteService;
    InputService InputService;
    UIService UIService;

    [SerializeField] List<Image> _selectionArrows = new();
    [SerializeField] TMP_Text _musicLabel = null;
    [SerializeField] TMP_Text _sfxLabel = null;
    [SerializeField] TMP_Text _paletteLabel = null;

    int _currentSelectedIndex = 0;
    int _currentMusicIndex = 2;
    int _currentSfxIndex = 2;
    int _currentPaletteIndex = 0;

    void Awake()
    {
        InitServices();
        SubscribeToEvents();

        GetGameSettings();
    }

    void GetGameSettings()
    {
        float musicVolume = PlayerPrefs.HasKey("MusicVolume") ? PlayerPrefs.GetFloat("MusicVolume") : 2;
        _currentMusicIndex = (int)musicVolume;
        _musicLabel.text = musicVolume.ToString();
        float sfxVolume = PlayerPrefs.HasKey("SfxVolume") ? PlayerPrefs.GetFloat("SfxVolume") : 2;
        _currentSfxIndex = (int)sfxVolume;
        _sfxLabel.text = sfxVolume.ToString();
        int paletteIndex = PlayerPrefs.HasKey("Palette") ? PlayerPrefs.GetInt("Palette") : 0;
        _currentPaletteIndex = paletteIndex;
        _paletteLabel.text = (paletteIndex + 1).ToString();
    }

    public override void ShowScreen()
    {
        base.ShowScreen();

        _screenActive = true;

        _currentSelectedIndex = 0;

        _selectionArrows[_currentSelectedIndex].enabled = true;

        InputService.SwitchActionMap(InputMapType.Menu);
    }

    public override void HideScreen()
    {
        base.HideScreen();

        _selectionArrows[_currentSelectedIndex].enabled = false;

        _screenActive = false;
    }

    void InitServices()
    {
        PaletteService ??= ServiceLocator.GetService<PaletteService>();
        InputService ??= ServiceLocator.GetService<InputService>();
        UIService ??= ServiceLocator.GetService<UIService>();
    }

    void SubscribeToEvents()
    {
        InputService.UpPressed += OnUpPressed;
        InputService.DownPressed += OnDownPressed;
        InputService.LeftPressed += OnLeftPressed;
        InputService.RightPressed += OnRightPressd;
        InputService.SelectPressed += OnSelectPressed;
        InputService.ExitPressed += OnExitPressed;
    }

    void OnDestroy()
    {
        InputService.UpPressed -= OnUpPressed;
        InputService.DownPressed -= OnDownPressed;
        InputService.LeftPressed -= OnLeftPressed;
        InputService.RightPressed -= OnRightPressd;
        InputService.SelectPressed -= OnSelectPressed;
        InputService.ExitPressed -= OnExitPressed;
    }

    void OnUpPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex--;
        if (_currentSelectedIndex < 0)
            _currentSelectedIndex = _selectionArrows.Count - 1;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnDownPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex++;
        if (_currentSelectedIndex >= _selectionArrows.Count)
            _currentSelectedIndex = 0;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnLeftPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        switch (_currentSelectedIndex)
        {
            case 0:
                _currentMusicIndex--;
                UpdateMusicVolume();
                break;
            case 1:
                _currentSfxIndex--;
                UpdateSfxVolume();
                break;
            case 2:
                _currentPaletteIndex--;
                UpdatePalette();
                break;
        }
    }

    void OnRightPressd()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        switch (_currentSelectedIndex)
        {
            case 0:
                _currentMusicIndex++;
                UpdateMusicVolume();
                break;
            case 1:
                _currentSfxIndex++;
                UpdateSfxVolume();
                break;
            case 2:
                _currentPaletteIndex++;
                UpdatePalette();
                break;
        }
    }

    void UpdateMusicVolume()
    {
        if (_currentMusicIndex < 0)
            _currentMusicIndex = 0;
        if (_currentMusicIndex >= 11)
            _currentMusicIndex = 10;

        _musicLabel.text = _currentMusicIndex.ToString();

        SetMusicVolume(_currentMusicIndex);
    }

    void UpdateSfxVolume()
    {
        if (_currentSfxIndex < 0)
            _currentSfxIndex = 0;
        if (_currentSfxIndex >= 11)
            _currentSfxIndex = 10;

        _sfxLabel.text = _currentSfxIndex.ToString();

        SetSfxVolume(_currentSfxIndex);
    }

    void UpdatePalette()
    {
        if (_currentPaletteIndex < 0)
            _currentPaletteIndex = PaletteService.GetPaletteCount() - 1;
        if (_currentPaletteIndex >= PaletteService.GetPaletteCount())
            _currentPaletteIndex = 0;

        PaletteService.SetCurrentPaletteIndex(_currentPaletteIndex);

        int paletteLabel = _currentPaletteIndex + 1;
        _paletteLabel.text = paletteLabel.ToString();
    }

    // 0 = Music, 1 = Sfx, 2 = Palette, 3 = back
    void OnSelectPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonSelect");

        switch (_currentSelectedIndex)
        {
            case 3:
                _lastView.ToggleScreenActive(true);
                HideScreen();
                break;
        }
    }

    void OnExitPressed()
    {
        if (!_screenActive)
            return;
    }

    void SetMusicVolume(float value)
    {
        AudioService.AdjustMusicVolume(value);
    }

    void SetSfxVolume(float value)
    {
        AudioService.AdjustSfxVolume(value);
    }
}
