using UnityEngine;

public class EndScreen : View
{
    LevelManagementService LevelManagementService;
    InputService InputService;

    void Awake()
    {
        InitServices();
        SubscribeToEvents();


        InputService.SwitchActionMap(InputMapType.Menu);
        _screenActive = true;
    }

    void InitServices()
    {
        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();
        InputService ??= ServiceLocator.GetService<InputService>();
    }

    void SubscribeToEvents()
    {
        InputService.SelectPressed += OnSelectPressed;
    }

    void OnDestroy()
    {
        InputService.SelectPressed -= OnSelectPressed;
    }

    void OnSelectPressed()
    {
        if (!_screenActive)
            return;

        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();

        LevelManagementService.LoadSpecificLevel(1);
    }
}
