using TMPro;
using UnityEngine;

public class StoryScreen : View
{
    [SerializeField] TMP_Text _storyText = null;

    public override void HideScreen()
    {
        base.HideScreen();

        ClearStoryText();
    }

    public void SetStoryText(string text)
    {
        _storyText.text = text;
    }

    public void ClearStoryText()
    {
        _storyText.text = string.Empty;
    }
}
