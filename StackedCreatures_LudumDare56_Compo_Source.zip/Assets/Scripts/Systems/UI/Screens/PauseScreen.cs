using Messaging;
using Messaging.Messages;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseScreen : View
{
    InputService InputService;
    UIService UIService;
    LevelManagementService LevelManagementService;

    [SerializeField] List<Image> _selectionArrows = new();
    int _currentSelectedIndex = 0;

    OptionsScreen _optionsView;

    void Awake()
    {
        InitServices();
        SubscribeToEvents();
    }

    public override void ShowScreen()
    {
        base.ShowScreen();

        _currentSelectedIndex = 0;

        _selectionArrows[_currentSelectedIndex].enabled = true;

        InputService.SwitchActionMap(InputMapType.Menu);

        _screenActive = true;
    }

    public override void HideScreen()
    {
        base.HideScreen();

        _selectionArrows[_currentSelectedIndex].enabled = false;

        _screenActive = false;
    }

    void InitServices()
    {
        InputService ??= ServiceLocator.GetService<InputService>();
        UIService ??= ServiceLocator.GetService<UIService>();
    }

    void SubscribeToEvents()
    {
        InputService.UpPressed += OnUpPressed;
        InputService.DownPressed += OnDownPressed;
        InputService.LeftPressed += OnLeftPressed;
        InputService.RightPressed += OnRightPressd;
        InputService.SelectPressed += OnSelectPressed;
        InputService.ExitPressed += OnExitPressed;
    }

    void OnDestroy()
    {
        InputService.UpPressed -= OnUpPressed;
        InputService.DownPressed -= OnDownPressed;
        InputService.LeftPressed -= OnLeftPressed;
        InputService.RightPressed -= OnRightPressd;
        InputService.SelectPressed -= OnSelectPressed;
        InputService.ExitPressed -= OnExitPressed;
    }

    void OnUpPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex--;
        if (_currentSelectedIndex < 0)
            _currentSelectedIndex = _selectionArrows.Count - 1;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnDownPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex++;
        if (_currentSelectedIndex >= _selectionArrows.Count)
            _currentSelectedIndex = 0;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnLeftPressed()
    {
        if (!_screenActive)
            return;
    }

    void OnRightPressd()
    {
        if (!_screenActive)
            return;
    }

    // 0 = continue, 1 = options 2 = restart level 3 = main menu

    void OnSelectPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonSelect");

        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();
        UIService ??= ServiceLocator.GetService<UIService>();

        switch (_currentSelectedIndex)
        {
            case 0:
                Time.timeScale = 1;
                InputService.SwitchActionMap(InputMapType.Gameplay);
                HideScreen();
                break;
            case 1:
                _optionsView ??= UIService.GetView("OptionsScreen") as OptionsScreen;
                _screenActive = false;
                _optionsView.SetLastView(this);
                _optionsView.ShowScreen();
                break;
            case 2:
                MessageHub.Publish(new RestartLevelMessage());
                Time.timeScale = 1;
                InputService.SwitchActionMap(InputMapType.Gameplay);
                HideScreen();
                break;
            case 3:
                LevelManagementService.LoadSpecificLevel(1);
                Time.timeScale = 1;
                HideScreen();
                break;
        }
    }

    void OnExitPressed()
    {
        if (!_screenActive)
            return;
    }
}
