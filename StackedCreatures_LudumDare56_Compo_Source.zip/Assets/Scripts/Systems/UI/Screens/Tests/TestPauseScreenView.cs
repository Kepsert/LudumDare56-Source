using UnityEngine;

public class TestPauseScreenView : View
{
    public void TestDebug()
    {
        Debug.Log("TestDebugSuccess");
    }
}
