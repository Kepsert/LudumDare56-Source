using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuScreen : View
{
    LevelManagementService LevelManagementService;
    InputService InputService;
    UIService UIService;

    [SerializeField] List<Image> _selectionArrows = new();
    [SerializeField] GameObject _menuPanel = null;
    [SerializeField] GameObject _pressStartToContinue = null;

    int _currentSelectedIndex = 0;

    bool _startToContinueActive;

    OptionsScreen _optionsView;

    void Awake()
    {
        InitServices();
        SubscribeToEvents();

        _screenActive = true;

        _selectionArrows[_currentSelectedIndex].enabled = true;

        InputService.SwitchActionMap(InputMapType.Menu);

        Time.timeScale = 1;

        _startToContinueActive = true;
        _screenActive = false;

        AudioService.StopSoundtrack();

        _optionsView = UIService.GetView("OptionsScreen") as OptionsScreen;
    }

    public override void ShowScreen()
    {
        base.ShowScreen();

        _screenActive = true;

        _selectionArrows[_currentSelectedIndex].enabled = true;

        InputService.SwitchActionMap(InputMapType.Menu);
    }

    public override void HideScreen()
    {
        base.HideScreen();

        _screenActive = false;
    }

    void InitServices()
    {
        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();
        AudioService ??= ServiceLocator.GetService<AudioService>();
        InputService ??= ServiceLocator.GetService<InputService>();
        UIService ??= ServiceLocator.GetService<UIService>();
    }

    void SubscribeToEvents()
    {
        InputService.UpPressed += OnUpPressed;
        InputService.DownPressed += OnDownPressed;
        InputService.LeftPressed += OnLeftPressed;
        InputService.RightPressed += OnRightPressd;
        InputService.SelectPressed += OnSelectPressed;
        InputService.ExitPressed += OnExitPressed;
    }

    void OnDestroy()
    {
        InputService.UpPressed -= OnUpPressed;
        InputService.DownPressed -= OnDownPressed;
        InputService.LeftPressed -= OnLeftPressed;
        InputService.RightPressed -= OnRightPressd;
        InputService.SelectPressed-= OnSelectPressed;
        InputService.ExitPressed -= OnExitPressed;
    }

    void OnUpPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex--;
        if (_currentSelectedIndex < 0)
            _currentSelectedIndex = _selectionArrows.Count - 1;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnDownPressed()
    {
        if (!_screenActive)
            return;

        PlayAudio("ButtonHover");

        _selectionArrows[_currentSelectedIndex].enabled = false;
        _currentSelectedIndex++;
        if (_currentSelectedIndex >= _selectionArrows.Count)
            _currentSelectedIndex = 0;
        _selectionArrows[_currentSelectedIndex].enabled = true;
    }

    void OnLeftPressed()
    {
        if (!_screenActive)
            return;
    }

    void OnRightPressd()
    {
        if (!_screenActive)
            return;
    }

    // 0 = play, 1 = options 2 = exit
    void OnSelectPressed()
    {
        if (_startToContinueActive)
        {
            StartCoroutine(SelectPressedCoroutine());
            PlayAudio("SelectPressed");
            return;
        }

        if (!_screenActive)
            return;

        PlayAudio("ButtonSelect");

        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();

        switch (_currentSelectedIndex)
        {
            case 0:
                LevelManagementService.LoadSpecificLevel(2);
                _screenActive = false;
                break;
            case 1:
                _screenActive = false;
                _optionsView.SetLastView(this);
                _optionsView.ShowScreen();
                break;
            case 2:
                Application.Quit();
                break;
        }
    }

    IEnumerator SelectPressedCoroutine()
    {
        _pressStartToContinue.SetActive(false);
        yield return new WaitForSeconds(0.15f);
        _pressStartToContinue.SetActive(true);
        yield return new WaitForSeconds(0.15f);
        _pressStartToContinue.SetActive(false);
        yield return new WaitForSeconds(0.15f);
        _pressStartToContinue.SetActive(true);
        yield return new WaitForSeconds(0.15f);
        _pressStartToContinue.SetActive(false);

        _startToContinueActive = false;
        _pressStartToContinue.SetActive(false);
        _menuPanel.SetActive(true);
        AudioService.PlaySoundtrack("Menu");
        _screenActive = true;
    }

    void OnExitPressed()
    {
        if (!_screenActive)
            return;
    }
}
