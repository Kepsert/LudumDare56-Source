using System.Collections.Generic;
using UnityEngine;

public class UIService : MonoBehaviour
{
    [SerializeField] UIConfig _uiConfig = null;

    Dictionary<string, View> _dictionaryScreenByName = new();

    List<View> _viewStack = new();

    View _currentView;

    void Awake()
    {
        if (_uiConfig != null)
            _uiConfig.Init();

        foreach (UIData data in _uiConfig.UIDataList)
            RegisterUIScreen(data.screenName);

    }

    public void RegisterUIScreen(string screenName)
    {
        if (!_dictionaryScreenByName.ContainsKey(screenName))
        {
            if (_uiConfig.DictionaryScreenByName.ContainsKey(screenName))
            {
                GameObject uiScreen = GameObject.Instantiate(_uiConfig.DictionaryScreenByName[screenName], transform);
                View view = uiScreen.GetComponent<View>();
                _dictionaryScreenByName.TryAdd(screenName, view);
                if (view != null)
                    view.HideScreen();
                else
                {
                    Debug.LogWarning($"UI Screen '{uiScreen.name}' does not have a View component");
                    return;
                }
            }
            else
            {
                Debug.LogWarning($"ScreenName '{screenName}' doesn't excist in _uiConfig");
                return;
            }
        }
    }

    public void ShowScreen(string screenName, bool hideLastScreen = false)
    {
        if (!_dictionaryScreenByName.ContainsKey(screenName))
        {
            RegisterUIScreen(screenName);
            ShowScreen(screenName, hideLastScreen);
        }
        else
        {
            if (_currentView != null && hideLastScreen)
                _currentView.HideScreen();

            View view = _dictionaryScreenByName[screenName];
            _currentView = view;
            if (view != null)
            {
                ShowScreen(view);
            }
            else
                Debug.LogWarning($"UI Screen '{_currentView.name}' does not have a View component");
        }
    }

    void ShowScreen(View view)
    {
        _viewStack.Add(view);
        view.ShowScreen();
    }

    public void HideScreen(string screenName)
    {
        if (!_dictionaryScreenByName.ContainsKey(screenName))
        {
            RegisterUIScreen(screenName);
        }
        else
        {
            _currentView = null;

            View view = _dictionaryScreenByName[screenName];
            if (view != null)
                view.HideScreen();
            else
                Debug.LogWarning($"UI Screen '{view.name}' does not have a View component");
        }
    }

    public void HideCurrentScreen()
    {
        if (_currentView == null)
            return;

        View view = _currentView.GetComponent<View>();
        if (view != null)
            view.HideScreen();
        else
            Debug.LogWarning($"UI Screen '{_currentView.name}' does not have a View component");
    }

    public void ToggleUIElement(string elementName, bool state)
    {
        if (_currentView != null)
        {
            Transform element = _currentView.transform.Find(elementName);
            if (element != null)
            {
                element.gameObject.SetActive(state);
            }
            else
            {
                Debug.LogWarning($"Element '{elementName}' not found in the current screen.");
            }
        }
    }

    public void RemoveScreen(string screenName)
    {
        if (_dictionaryScreenByName.ContainsKey(screenName))
        {
            GameObject uiScreen = _dictionaryScreenByName[screenName].gameObject;
            _dictionaryScreenByName.Remove(screenName);
            Destroy(uiScreen);
        }
        else
            Debug.LogError($"Can't delete screen '{screenName}' because it doesn't exist yet.");
    }

    public View GetView(string screenName)
    {
        if (!_dictionaryScreenByName.ContainsKey(screenName))
        {
            RegisterUIScreen(screenName);
            ShowScreen(screenName);
            if (!_dictionaryScreenByName.ContainsKey(screenName))
            {
                Debug.LogError($"Screen named '{screenName}' was not able to be created and thus not gotten.");
                return null;
            }
            return _dictionaryScreenByName[screenName];
        }
        else
        {
            return _dictionaryScreenByName[screenName];
        }
    }

    public void RemoveFromStack(string screenName)
    {
        if (_dictionaryScreenByName.ContainsKey(screenName))
        {
            View view = _dictionaryScreenByName[screenName];
            if (_viewStack.Contains(view))
            {
                RemoveFromStack(view);
            }
        }
    }

    void RemoveFromStack(View view)
    {
        if (_viewStack.Contains(view))
        {
            if (_currentView == view)
            {
                _currentView.HideScreen();
                _currentView = null;
            }
            _viewStack.Remove(view);
        }
    }

    public void OpenLastViewOnStack()
    {
        if (_viewStack.Count >= 2)
        {
            _currentView.HideScreen();
            RemoveFromStack(_viewStack[_viewStack.Count - 1]);
            _currentView = _viewStack[_viewStack.Count - 1];
            _currentView.ShowScreen();
        }
        else
            Debug.LogWarning("Can not open last view on stack cause there is no previous view on stack");
    }

    public void HideAllScreens()
    {
        if (_dictionaryScreenByName.Count > 0)
        {
            foreach (KeyValuePair<string, View> kvp in _dictionaryScreenByName)
                kvp.Value.HideScreen();
        }
    }

    public void ClearViewStack()
    {
        _viewStack.Clear();
    }

    [ContextMenu("Test Hide TestPauseScreen")]
    public void TestHideTestPauseScreen()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        if (uiService != null)
            uiService.HideScreen("TestPauseScreen");
    }

    [ContextMenu("Test Remove TestPauseScreen")]
    public void TestRemoveTestPauseScreen()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        if (uiService != null)
            uiService.RemoveScreen("TestPauseScreen");
    }

    [ContextMenu("Test Get TestPauseScreen")]
    public void TestGetTestPauseScreen()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        if (uiService == null)
            return;

        TestPauseScreenView testPauseScreenView = uiService.GetView("TestPauseScreen") as TestPauseScreenView;
        testPauseScreenView.TestDebug();
    }

    [ContextMenu("Test Get TestMenuScreen")]
    public void TestGetTestMenuScreen()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        if (uiService == null)
            return;

        TestMenuScreenView testMenuScreenView = uiService.GetView("TestMenuScreen") as TestMenuScreenView;
    }

    [ContextMenu("Test Open Last Stack")]
    public void TestOpenLastScreenOnStack()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        if (uiService == null)
            return;

        uiService.OpenLastViewOnStack();
    }

    [ContextMenu("Load Test Menu Screen View")]
    public void TestShowMenuScreenView()
    {
        UIService uiService = ServiceLocator.GetService<UIService>();
        uiService.ShowScreen("TestMenuScreen");
    }
}
