using Cysharp.Threading.Tasks;
using UnityEngine;

public class View : MonoBehaviour
{
    [SerializeField] protected CanvasGroup _canvasGroup = null;
    [SerializeField] bool _instantlyHide = false;

    protected AudioService AudioService;

    protected bool _screenActive;
    protected View _lastView;

    private void Awake()
    {
        InitView();
    }

    void InitView()
    {
        if (_instantlyHide)
            HideScreen();
    }

    public virtual void HideScreen()
    {
        _canvasGroup.alpha = 0;
        _canvasGroup.interactable = false;
        _canvasGroup.blocksRaycasts = false;
    }

    public virtual void ShowScreen()
    {
        _canvasGroup.alpha = 1;
        _canvasGroup.interactable = true;
        _canvasGroup.blocksRaycasts = true;
    }

    public virtual void ToggleScreenActive(bool toggle)
    {
        DelayActivatingLastView(toggle);
    }

    public virtual void SetLastView(View view)
    {
        _lastView = view;
    }

    async UniTask DelayActivatingLastView(bool toggle)
    {
        await UniTask.DelayFrame(10);

        _screenActive = toggle;
        _lastView = null;
    }

    protected void PlayAudio(string name)
    {
        AudioService ??= ServiceLocator.GetService<AudioService>();

        AudioService.PlaySfxSound(name, AudioType.Sfx);
    }
}
