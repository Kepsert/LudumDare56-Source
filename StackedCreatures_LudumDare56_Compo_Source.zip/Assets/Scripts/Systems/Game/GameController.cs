using System;

public class GameController
{
    GameState _state = GameState.MainMenu;
    public GameState GameState => _state;
    public Action<GameState> onChangeState;
    public void SetGameState(GameState state)
    {
        _state = state;
        onChangeState?.Invoke(_state);
    }

    GameMode _mode = GameMode.Normal;
    public GameMode Mode => _mode;
    public Action<GameMode> onChangeMode;
    public void SetGameMode(GameMode mode)
    {
        _mode = mode;
        onChangeMode?.Invoke(_mode);
    }
}

public enum GameState
{
    MainMenu = 0,
    Play = 1,
    Pause = 2,
    Loading = 4,
    Cutscene = 8,
    EndGame = 16,
}

public enum GameMode
{
    Normal = 0,
    Speedrun = 1,
}