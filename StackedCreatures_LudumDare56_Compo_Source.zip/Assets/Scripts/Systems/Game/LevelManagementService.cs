using Cysharp.Threading.Tasks;
using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManagementService
{
    UIService UIService;
    FadeScreen _fadeScreen;

    public event Action OnLevelLoadStarted;
    public event Action OnLevelLoadCompleted;
    public event Action OnLevelUnloadStarted;
    public event Action OnLevelUnloadCompleted;

    int _currentLevelIndex = 0;
    string _currentLevelName = string.Empty;

    public int CurrentLevelIndex => _currentLevelIndex;
    public string CurrentLevelName => _currentLevelName;

    int _amountOfCoins;
    public int AmountOfCoins => _amountOfCoins;

    bool _loadingLevel;

    public void RestartLevel(float delay = 0)
    {
        int currentLevel = SceneManager.GetActiveScene().buildIndex;
        ActuallyLoadLevel(currentLevel, delay);
    }

    public void LoadNextLevel(float delay = 0)
    {
        int nextLevel = SceneManager.GetActiveScene().buildIndex + 1;
        if (nextLevel < SceneManager.sceneCountInBuildSettings)
            ActuallyLoadLevel(nextLevel, delay);
        else
            ActuallyLoadLevel(1, delay);
    }

    public void LoadSpecificLevel(int level, float delay = 0)
    {
        if (level >= 0 && level < SceneManager.sceneCountInBuildSettings)
            ActuallyLoadLevel(level, delay);
        else
            Debug.LogError($"Can't load scene number '{level}' because it doesn't exist in build settings.");
    }

    async UniTask ActuallyLoadLevel(int level, float delay = 0)
    {
        if (!_loadingLevel)
        {
            _loadingLevel = true;

            await UniTask.Delay(TimeSpan.FromSeconds(delay));

            UIService ??= ServiceLocator.GetService<UIService>();

            _fadeScreen ??= UIService.GetView("FadeScreen") as FadeScreen;

            _currentLevelIndex = level;

            _fadeScreen.ShowScreen();

            OnLevelLoadStarted?.Invoke();
            await _fadeScreen.FadeOut();
            SceneManager.LoadScene(level);

            _loadingLevel = false;

            await _fadeScreen.FadeIn(.25f);
            OnLevelLoadCompleted?.Invoke();
        }
    }

    public void LoadLevelByName(string levelName)
    {
        if (Application.CanStreamedLevelBeLoaded(levelName))
            SceneManager.LoadScene(levelName);
        else
            Debug.LogError($"Can't load scene with name '{levelName}' because it doesn't exist in build settings.");
    }

    public async UniTask RespawnLevelAtCheckpoint()
    {
        UIService ??= ServiceLocator.GetService<UIService>();

        _fadeScreen ??= UIService.GetView("FadeScreen") as FadeScreen;

        _fadeScreen.ShowScreen();

        await _fadeScreen.FadeOut();
    }

    public async UniTask RespawnedAtCheckpoint()
    {
        UIService ??= ServiceLocator.GetService<UIService>();

        _fadeScreen ??= UIService.GetView("FadeScreen") as FadeScreen;

        _fadeScreen.ShowScreen();

        await _fadeScreen.FadeIn(.5f);
    }

    public async UniTask LoadLevelAsync(int levelIndex)
    {
        OnLevelLoadStarted?.Invoke();

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(levelIndex, LoadSceneMode.Additive);
        asyncLoad.allowSceneActivation = false;

        while (!asyncLoad.isDone)
        {
            if (asyncLoad.progress >= 0.9f)
            {
                asyncLoad.allowSceneActivation = true;
            }

            await UniTask.Yield();
        }

        _currentLevelIndex = levelIndex;
        _currentLevelName = SceneManager.GetSceneByBuildIndex(levelIndex).name;

        OnLevelLoadCompleted?.Invoke();
    }

    public async UniTask LoadLevelAsync(string levelName)
    {
        OnLevelLoadStarted?.Invoke();

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(levelName, LoadSceneMode.Additive);
        asyncLoad.allowSceneActivation = false;

        while (!asyncLoad.isDone)
        {
            if (asyncLoad.progress >= 0.9f)
            {
                asyncLoad.allowSceneActivation = true;
            }

            await UniTask.Yield();
        }

        _currentLevelIndex = SceneManager.GetSceneByName(levelName).buildIndex;
        _currentLevelName = levelName;

        OnLevelLoadCompleted?.Invoke();
    }

    public async UniTask UnloadCurrentLevelAsync(bool resetLevelIndex = false)
    {
        if (SceneManager.sceneCount > 1)
        {
            _currentLevelIndex = GetActiveScene();
            if (_currentLevelIndex < 0)
            {
                Debug.LogWarning("No level is currently loaded.");
                return;
            }

            OnLevelUnloadStarted?.Invoke();

            AsyncOperation asyncUnload = SceneManager.UnloadSceneAsync(_currentLevelIndex);
            while (!asyncUnload.isDone)
            {
                await UniTask.Yield();
            }

            if (resetLevelIndex)
            {
                _currentLevelIndex = -1;
                _currentLevelName = string.Empty;
            }

            OnLevelUnloadCompleted?.Invoke();
        }
        else
            Debug.LogWarning("Cannot unload the only loaded scene. Load another scene first.");
    }

    public async UniTask RestartLevelAsync()
    {
        _currentLevelIndex = GetActiveScene();
        if (_currentLevelIndex >= 0)
        {
            await UnloadCurrentLevelAsync();
            await LoadLevelAsync(_currentLevelIndex);
        }
        else
        {
            Debug.LogWarning("No level to restart.");
        }
    }

    public async UniTask LoadNextLevelAsync()
    {
        _currentLevelIndex = GetActiveScene();
        if (_currentLevelIndex < SceneManager.sceneCountInBuildSettings - 1)
        {
            if (_currentLevelIndex >= 0)
            {
                await UnloadCurrentLevelAsync();
                await LoadLevelAsync(_currentLevelIndex + 1);
            }
            else
            {
                Debug.LogWarning("No current level to advance from.");
            }
        }
        else
        {
            Debug.LogWarning($"Trying to load level '{_currentLevelIndex + 1}' but it doesn't exist");
        }
    }

    public async UniTask LoadSelectedLevelAsync(int levelIndex)
    {
        if (_currentLevelIndex >= 0)
        {
            await UnloadCurrentLevelAsync();
        }
        await LoadLevelAsync(levelIndex);
    }

    public int GetActiveScene()
    {
        return _currentLevelIndex;
    }
}
