using System.Collections.Generic;
using UnityEngine;

public class EffectPool
{
    readonly Queue<GameObject> _pool;
    readonly GameObject _prefab;
    readonly Transform _parent;
    readonly string _name;
    float _defaultduration;

    public EffectPool(GameObject prefab, string effectName, int initialSize, Transform parent = null)
    {
        _prefab = prefab;
        _parent = parent;
        _name = effectName;
        _pool = new Queue<GameObject>();

        for (int i = 0; i < initialSize; i++)
        {
            GameObject obj = CreateNewEffect();
            _pool.Enqueue(obj);
        }
    }

    private GameObject CreateNewEffect()
    {
        GameObject effect = GameObject.Instantiate(_prefab, _parent);
        effect.name = _name;
        if (effect.TryGetComponent(out ParticleSystem particleSystem))
            particleSystem.Stop();
        else
            effect.SetActive(false);
        return effect;
    }

    public GameObject GetEffect()
    {
        if (_pool.Count > 0)
        {
            GameObject effect = _pool.Dequeue();
            effect.SetActive(true);
            return effect;
        }
        else
            return CreateNewEffect();
    }

    public void ReturnToPool(GameObject effect)
    {
        if (effect.TryGetComponent(out ParticleSystem particleSystem))
            particleSystem.Stop();
        else
            effect.SetActive(false);
        _pool.Enqueue(effect);
    }
}
