using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectService : MonoBehaviour
{
    [SerializeField] EffectConfig _effectConfig = null;
    [SerializeField] int _initialPoolSize = 5;

    Dictionary<string, EffectPool> _dictionaryEffectPoolByName = new();
    Dictionary<GameObject, Coroutine> _dictionaryActiveEffects = new();

    void Awake()
    {
        Init();
    }

    void Init()
    {
        if (_effectConfig != null)
            _effectConfig.Init();
        else
            Debug.LogWarning($"EffectConfig is missing from '{this}'");

        foreach (KeyValuePair<string, EffectData> kvp in _effectConfig.DictionaryEffectDataByName)
        {
            if (!_dictionaryEffectPoolByName.ContainsKey(kvp.Key))
            {
                EffectData data = _effectConfig.DictionaryEffectDataByName[kvp.Key];
                var pool = new EffectPool(data.effectPrefab, data.effectName, _initialPoolSize, this.transform);
                _dictionaryEffectPoolByName.Add(data.effectName, pool);
            }
        }
    }

    public void PlayEffect(string effectName, Vector3 position, Quaternion? rotation = null, Vector3? scale = null, Transform parent = null, float? duration = null)
    {
        if (!_dictionaryEffectPoolByName.ContainsKey(effectName))
        {
            Debug.LogWarning($"Effect with name '{effectName}' is not present in the pool library.");
            return;
        }

        GameObject effect = _dictionaryEffectPoolByName[effectName].GetEffect();
        if (rotation.HasValue)
            effect.transform.SetPositionAndRotation(position, rotation.Value);
        else
            effect.transform.SetPositionAndRotation(position, Quaternion.identity);
        
        if (parent != null)
            effect.transform.SetParent(parent);

        if (scale.HasValue)
            effect.transform.localScale = scale.Value;

        PlayEffectAnimation(effect);

        EffectData data = _effectConfig.DictionaryEffectDataByName[effectName];

        float effectDuration = (duration.HasValue) ? duration.Value : data.effectDuration;

        Coroutine effectCoroutine = StartCoroutine(ReturnEffectToPool(effect, effectDuration));

        if (_dictionaryActiveEffects.ContainsKey(effect))
            _dictionaryActiveEffects[effect] = effectCoroutine;
        else
            _dictionaryActiveEffects.TryAdd(effect, effectCoroutine);
    }

    void PlayEffectAnimation(GameObject effect)
    {
        if (effect.TryGetComponent(out ParticleSystem particleSystem))
            particleSystem.Play();
    }

    IEnumerator ReturnEffectToPool(GameObject effect, float effectDuration)
    {
        yield return new WaitForSeconds(effectDuration);
        if (_dictionaryActiveEffects.TryGetValue(effect, out var coroutine))
        {
            StopCoroutine(coroutine);
            _dictionaryActiveEffects.Remove(effect);
        }
        _dictionaryEffectPoolByName[effect.name].ReturnToPool(effect);
    }

    [ContextMenu("Play TestEffect")]
    public void PlayTestEffect()
    {
        EffectService effectService = ServiceLocator.GetService<EffectService>();
        effectService.PlayEffect("TestEffect", this.transform.position, Quaternion.identity, new Vector3(1, 1, 1));
    }
}
