using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "EffectConfig", menuName = "Config/Effect", order = 3)]
public class EffectConfig : ScriptableObject
{
    [SerializeField] List<EffectData> _effectsList = new();
    Dictionary<string, EffectData> _dictionaryEffectDataByName = new();
    public Dictionary<string, EffectData> DictionaryEffectDataByName => _dictionaryEffectDataByName;

    public void Init()
    {
        foreach (EffectData effectData in _effectsList)
        {
            if (!_dictionaryEffectDataByName.ContainsKey(effectData.effectName))
                _dictionaryEffectDataByName.TryAdd(effectData.effectName, effectData);
        }
    }
}

[System.Serializable]
public struct EffectData
{
    public string effectName;
    public GameObject effectPrefab;
    public float effectDuration;
}
