using System;
using System.Collections.Generic;
using UnityEngine;

public static class ServiceLocator
{
    private static readonly Dictionary<Type, object> _services = new();

    public static void RegisterService<T>(Type type, T service)
    {
        if (_services.ContainsKey(type))
        {
            Debug.LogWarning($"Service '{type.Name}' is already registered.");
            return;
        }
        Debug.Log($"Registering service '{type.Name}'");
        _services.Add(type, service);
    }

    public static T GetService<T>()
    {
        Type type = typeof(T);
        if (_services.TryGetValue(type, out var service))
            return (T)service;
        Debug.LogError($"Service '{type.Name}' is not registered.");
        return default;
    }

    public static void UnregisterService<T>()
    {
        var type = typeof(T);
        if (_services.ContainsKey(type))
            _services.Remove(type);
        else
            Debug.LogWarning($"Service '{type.Name}' is not registered.");
    }
}
