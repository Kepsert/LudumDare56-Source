using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Services
{
    [DefaultExecutionOrder(-10000)]
    public class ServiceLoader : MonoBehaviour
    {
        public static ServiceLoader Instance;

        [SerializeField] List<ServiceObject> _serviceList = new();
        [SerializeField] string _screenToShow = "TestPauseScreen";
        [SerializeField] string _sceneToLoad = string.Empty;

        float _loadTime = 0f;
        bool _loading = false;

        async void Awake()
        {
            if (Instance == null)
            {
                DontDestroyOnLoad(this);
                Instance = this;

                _loading = true;
                Debug.Log("Start initializing services");

                await Init();

                _loading = false;
                Debug.Log($"Finished initializing services. Took '{_loadTime}' seconds.");

                if (!string.IsNullOrEmpty(_sceneToLoad))
                    LoadFirstScene();
                if (!string.IsNullOrEmpty(_screenToShow))
                    ShowMenuScreen();
            }
            else
            {
                DestroyImmediate(gameObject);
            }
        }

        void LoadFirstScene()
        {
            LevelManagementService levelManagementService = ServiceLocator.GetService<LevelManagementService>();
            levelManagementService.LoadNextLevel();
            GameController gameController = ServiceLocator.GetService<GameController>();
            gameController.SetGameState(GameState.Play);
        }

        void ShowMenuScreen()
        {
            UIService uiService = ServiceLocator.GetService<UIService>();
            if (uiService != null)
            {
                if (!string.IsNullOrEmpty(_screenToShow))
                {
                    uiService.ShowScreen(_screenToShow);
                }
                else
                    Debug.LogWarning("Can not disable loaderscene cam cause it's not hooked up");
            }
        }

        async UniTask Init()
        {
            foreach (var serviceObject in _serviceList)
            {
                if (serviceObject.servicePrefab == null)
                    RegisterNonPrefabService(serviceObject);
                else
                    InitiatePrefab(serviceObject);
            }
            await UniTask.WaitForSeconds(0.025f);
        }

        void RegisterNonPrefabService(ServiceObject serviceObject)
        {
            Type serviceType = Type.GetType(serviceObject.serviceName);
            if (serviceType != null)
            {
                var serviceInstance = Activator.CreateInstance(serviceType);
                if (serviceInstance != null)
                {
                    ServiceLocator.RegisterService(serviceType, serviceInstance);
                }
                else
                    Debug.LogError($"Failed to create an instance of '{serviceType.FullName}'");

            }
            else
                Debug.LogError($"Service type '{serviceObject.serviceName}' not found.");
        }

        void InitiatePrefab(ServiceObject config, bool dontDestroy = true)
        {
            Type serviceType = Type.GetType(config.serviceName);
            if (GameObject.FindObjectOfType(serviceType) != null)
                return;

            GameObject serviceObject = Instantiate(config.servicePrefab);

            if (dontDestroy)
                DontDestroyOnLoad(serviceObject);

            if (serviceType != null)
            {
                Component serviceComponent = serviceObject.GetComponent(serviceType);
                if (serviceComponent != null)
                {
                    ServiceLocator.RegisterService(serviceType, serviceComponent);
                }
                else
                    Debug.LogError($"Service component of type '{serviceType.Name}' not found on the game object");
            }
            else
                Debug.LogError($"Service type '{config.serviceName}' not found.");
        }

        void Update()
        {
            if (_loading)
                _loadTime += Time.deltaTime;
        }
    }
}