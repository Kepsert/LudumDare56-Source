using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Story", menuName = "Story/Story", order = 25)]
public class StoryConfig : ScriptableObject
{
    [SerializeField] List<StoryPiece> _storyList = new();
    public List<StoryPiece> StoryList => _storyList;
}

[System.Serializable]
public class StoryPiece
{
    [TextArea(3, 6)] public string StoryMessage;
    public float ScreenTime;
}
