using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class StoryService : MonoBehaviour
{
    LevelManagementService LevelManagementService;
    UIService UIService;
    InputService InputService;

    int _currentStoryPartIndex;

    CancellationToken _cancellationToken;
    CancellationTokenSource _cancellationTokenSource;

    List<StoryPiece> _storyList = new();

    StoryScreen _storyScreen;

    bool _storyActive;

    void Awake()
    {
        InitServices();
        InitViews();
    }

    void InitServices()
    {
        UIService ??= ServiceLocator.GetService<UIService>();
        LevelManagementService ??= ServiceLocator.GetService<LevelManagementService>();
        InputService ??= ServiceLocator.GetService<InputService>();
    }

    void Start()
    {
        SubscribeToEvents();
    }

    void SubscribeToEvents()
    {
        InputService.SelectPressed += OnSelectPressed;
    }

    private void OnSelectPressed()
    {
        if (!_storyActive)
            return;

        _currentStoryPartIndex++;

        if (_currentStoryPartIndex < _storyList.Count)
            PlayStory();
        else
            EndStory();
    }

    void InitViews()
    {
        _storyScreen = UIService.GetView("StoryScreen") as StoryScreen;
    }

    public void StartNewStory(StoryConfig config)
    {
        _cancellationTokenSource = new CancellationTokenSource();
        _cancellationToken = _cancellationTokenSource.Token;

        _storyList.Clear();
        _storyList = new(config.StoryList);
        _currentStoryPartIndex = 0;

        _storyScreen.ShowScreen();

        _storyActive = true;

        PlayStory();
    }

    void PlayStory()
    {
        StoryPiece storyPiece = _storyList[_currentStoryPartIndex];

        _storyScreen.SetStoryText(storyPiece.StoryMessage);
    }

    void EndStory()
    {
        _cancellationToken.ThrowIfCancellationRequested();

        LevelManagementService.LoadNextLevel();

        _storyScreen.HideScreen();

        _storyActive = false;

        CleanUp();
    }

    void CleanUp()
    {
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
        _cancellationTokenSource = null;
    }

    void OnDestroy()
    {
        CleanUp();
        InputService.SelectPressed -= OnSelectPressed;
    }
}
