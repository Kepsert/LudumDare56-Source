using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PaletteConfig", menuName = "Config/PaletteConfig", order = 15)]
public class PaletteConfig : ScriptableObject
{
    [SerializeField] List<Texture2D> _colourPaletteList = new();
    public List<Texture2D> ColourPaletteList => _colourPaletteList;
}
