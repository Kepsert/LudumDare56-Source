using System;
using UnityEngine;

public class PaletteService : MonoBehaviour
{
    [SerializeField] PaletteConfig _paletteConfig = null;
    [SerializeField] Material _paletteMaterial = null;

    public event Action<Color> OnPaletteSwap;

    Texture2D _currentPalette;
    Color _fontColor;
    int _currentPaletteIndex = 0;

    void Start()
    {
        _currentPaletteIndex = PlayerPrefs.HasKey("Palette") ? PlayerPrefs.GetInt("Palette") : 0;
        _currentPalette = _paletteConfig.ColourPaletteList[_currentPaletteIndex];
        ApplyPalette();
    }

    void ApplyPalette()
    {
        Shader.SetGlobalTexture("_GradientTex", _currentPalette);

        PlayerPrefs.SetInt("Palette", _currentPaletteIndex);

        _fontColor = GetLighterColor();
        OnPaletteSwap?.Invoke(_fontColor);
    }

    public int GetCurrentPaletteIndex()
    {
        return _currentPaletteIndex;
    }

    public Texture2D GetCurrentPalette()
    {
        return _currentPalette;
    }

    public void SetCurrentPaletteIndex(int index)
    {
        _currentPaletteIndex = index;

        _currentPalette = _paletteConfig.ColourPaletteList[_currentPaletteIndex];

        ApplyPalette();
    }

    void NextPalette()
    {
        Debug.Log("Pressing next palette");

        _currentPaletteIndex++;

        if (_currentPaletteIndex >= _paletteConfig.ColourPaletteList.Count)
            _currentPaletteIndex = 0;

        _currentPalette = _paletteConfig.ColourPaletteList[_currentPaletteIndex];

        ApplyPalette();
    }

    public Color GetFontColor()
    {
        return GetLighterColor();
    }

    public int GetPaletteCount()
    {
        return _paletteConfig.ColourPaletteList.Count;
    }

    Color GetLighterColor()
    {
        Color color1 = _currentPalette.GetPixel(0, 0);
        Color color2 = _currentPalette.GetPixel(_currentPalette.width - 1, 0);

        float luminance1 = color1.r * 0.299f + color1.g * 0.587f + color1.b * 0.114f;
        float luminance2 = color2.r * 0.299f + color2.g * 0.587f + color2.b * 0.114f;

        return luminance1 > luminance2 ? color1 : color2;
    }
}
