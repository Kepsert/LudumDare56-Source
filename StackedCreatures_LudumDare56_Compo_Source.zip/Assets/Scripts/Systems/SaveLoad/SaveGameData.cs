using System;
using System.Collections.Generic;

[Serializable]
public class SaveGameData
{
    public int LastLevelCompleted;
    public int Score;
    public int Collectibles;
    public int DeathCount;
    public Dictionary<int, bool> DictionayCollectibleGatheredByIndex = new();
}
