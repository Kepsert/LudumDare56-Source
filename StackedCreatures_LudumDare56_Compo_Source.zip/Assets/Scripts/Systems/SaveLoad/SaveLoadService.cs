using Newtonsoft.Json;
using System.IO;
using UnityEngine;

public class SaveLoadService
{
    private string _fileName = "savegame1.json";

    void SetSaveSlot(int slot)
    {
        _fileName = "savegame" + slot + ".json";
    }

    public void SaveGame(SaveGameData data, int slot)
    {
        SetSaveSlot(slot);

        string jsonData = JsonConvert.SerializeObject(data, Formatting.Indented);

        if (Application.platform == RuntimePlatform.WebGLPlayer)
        {
            PlayerPrefs.SetString(_fileName, jsonData);
            PlayerPrefs.Save();
        }
        else
        {
            string path = Path.Combine(Application.persistentDataPath, _fileName);
            File.WriteAllText(path, jsonData);
        }

        Debug.Log("Game Data Saved");
    }

    public SaveGameData LoadGame(int slot)
    {
        SetSaveSlot(slot);

        string jsonData;

        if (Application.platform == RuntimePlatform.WebGLPlayer)
        {
            if (PlayerPrefs.HasKey(_fileName))
                jsonData = PlayerPrefs.GetString(_fileName);
            else
            {
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' doesn't exist.");
                return null;
            }
        }
        else
        {
            string path = Path.Combine(Application.persistentDataPath, _fileName);
            if (File.Exists(path))
            {
                jsonData = File.ReadAllText(path);
            }
            else
            {
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' doesn't exist.");
                return null;
            }
        }

        return JsonConvert.DeserializeObject<SaveGameData>(jsonData);
    }

    public void UpdateSaveGameData(int slot, System.Action<SaveGameData> updateAction)
    {
        SetSaveSlot(slot);

        SaveGameData existingData = LoadGame(slot);

        if (existingData == null)
            existingData = new SaveGameData();

        updateAction(existingData);
        SaveGame(existingData, slot);
    }

    public bool DeleteSaveGame(int slot)
    {
        SetSaveSlot(slot);

        if (Application.platform == RuntimePlatform.WebGLPlayer)
        {
            if (PlayerPrefs.HasKey(_fileName))
            {
                PlayerPrefs.DeleteKey(_fileName);
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' has been deleted.");
                return true;
            }
            else
            {
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' doesn't exist.");
                return false;
            }
        }
        else
        {
            string path = Path.Combine(Application.persistentDataPath, _fileName);
            if (File.Exists(path))
            {
                File.Delete(path);
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' has been deleted.");
                return true;
            }
            else
            {
                Debug.LogWarning($"Save data with slot '{slot}' and filename '{_fileName}' doesn't exist.");
                return false;
            }
        }
    }

    #region TestMethodsExamples
    [ContextMenu("TestSaveLastLevel")]
    public void TestSaveLastLevel()
    {
        SaveLoadService saveLoadService = ServiceLocator.GetService<SaveLoadService>();
        saveLoadService.UpdateSaveGameData(1, data =>
        {
            data.LastLevelCompleted = 2;
        });
    }

    [ContextMenu("TestSaveDeathCount")]
    public void TestSaveDeathCount()
    {
        SaveLoadService saveLoadService = ServiceLocator.GetService<SaveLoadService>();
        saveLoadService.UpdateSaveGameData(1, data =>
        {
            data.DeathCount = 3;
        });
    }
    #endregion
}
