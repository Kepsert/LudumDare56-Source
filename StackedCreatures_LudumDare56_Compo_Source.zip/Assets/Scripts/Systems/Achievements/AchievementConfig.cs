using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "AchievementConfig", menuName = "Config/Achievement", order = 4)]
public class AchievementConfig : ScriptableObject
{
    [SerializeField] List<AchievementSO> _achievementsList = new();
    public List<AchievementSO> AchievementsList => _achievementsList;
}
