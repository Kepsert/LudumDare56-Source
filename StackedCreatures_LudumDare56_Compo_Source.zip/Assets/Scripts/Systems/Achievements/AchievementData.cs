using System.Collections.Generic;

public class AchievementData
{
    Dictionary<string, bool> _dictionaryAchievementUnlocked = new();
    public Dictionary<string, bool> DictionaryAchievementUnlocked => _dictionaryAchievementUnlocked;

    public int DeathCount = 0;
}
