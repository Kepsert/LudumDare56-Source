using System;
using System.Collections.Generic;
using UnityEngine;

public class AchievementService : MonoBehaviour
{
    [SerializeField] AchievementConfig _achievementConfig = null;
    public event Action<AchievementSO> OnAchievementUnlocked;

    AchievementData _achievementData;

    Dictionary<string, AchievementSO> _dictionaryAchievementById = new();

    void Awake()
    {
        InitDictionaries();
    }

    void InitDictionaries()
    {
        foreach (AchievementSO achievement in _achievementConfig.AchievementsList)
        {
            if (!_dictionaryAchievementById.ContainsKey(achievement.AchievementId))
                _dictionaryAchievementById.TryAdd(achievement.AchievementId, achievement);
        }
    }

    public void LoadAchievementData(AchievementData data)
    {
        _achievementData = data;

        foreach (var achievement in _achievementConfig.AchievementsList)
        {
            if (_achievementData.DictionaryAchievementUnlocked.ContainsKey(achievement.AchievementId))
            {
                if (_achievementData.DictionaryAchievementUnlocked[achievement.AchievementId])
                    achievement.Unlock();
                else
                    achievement.Lock();
            }
            else
                _achievementData.DictionaryAchievementUnlocked[achievement.AchievementId] = false;
        }

        foreach (KeyValuePair<string, bool> kvp in _achievementData.DictionaryAchievementUnlocked)
            Debug.Log($"Found achievement with id '{kvp.Key}'. Unlocked is '{kvp.Value}'");
    }

    public AchievementData GetAchievementData()
    {
        return _achievementData;
    }

    public void CheckAchievementProgress()
    {
        foreach (var achievement in _achievementConfig.AchievementsList)
        {
            if (!achievement.IsUnlocked && achievement.CheckUnlockCondition(_achievementData))
            {
                achievement.Unlock();
                OnAchievementUnlocked?.Invoke(achievement);
                _achievementData.DictionaryAchievementUnlocked[achievement.AchievementId] = true;
                Debug.Log($"Unlocked achievement with name '{achievement.AchievementName}' and Id '{achievement.AchievementId}'");
            }
        }
    }

    public void UnlockAchievementById(string id)
    {
        if (_dictionaryAchievementById.ContainsKey(id))
        {
            AchievementSO achievement = _dictionaryAchievementById[id];
            achievement.Unlock();
            OnAchievementUnlocked?.Invoke(achievement);
            _achievementData.DictionaryAchievementUnlocked[achievement.AchievementId] = true;
            Debug.Log($"Unlocked achievement with name '{achievement.AchievementName}' and Id '{achievement.AchievementId}'");
        }
    }

    public void ResetAchievements()
    {
        if (_achievementData != null)
        {
            foreach (var achievement in _achievementConfig.AchievementsList)
                achievement.Lock();
            foreach (var achievement in _achievementConfig.AchievementsList)
            {
                if (_achievementData.DictionaryAchievementUnlocked.ContainsKey(achievement.AchievementId))
                    _achievementData.DictionaryAchievementUnlocked[achievement.AchievementId] = false;
            }
        }
        else
            Debug.LogWarning($"Can't clear achievement data because no achievement data has been loaded.");
    }

    public List<AchievementSO> GetUnlockedAchievements()
    {
        return _achievementConfig.AchievementsList.FindAll(x => x.IsUnlocked);
    }

    public List<AchievementSO> GetLockedAchievements()
    {
        return _achievementConfig.AchievementsList.FindAll(x => !x.IsUnlocked);
    }

    public List<AchievementSO> GetAllAchievements()
    {
        return _achievementConfig.AchievementsList;
    }

    #region AchievementServiceTests
    [ContextMenu("Set Achievement Data")]
    public void TestSetAchievementData()
    {
        AchievementService achievementService = ServiceLocator.GetService<AchievementService>();
        AchievementData achievementData = new AchievementData
        {
            DeathCount = 0,
        };
        achievementService.LoadAchievementData(achievementData);
    }

    [ContextMenu("Test Increase Death Count")]
    public void TestIncreaseDeathCount()
    {
        AchievementService achievementService = ServiceLocator.GetService<AchievementService>();
        AchievementData achievementData = achievementService.GetAchievementData();
        achievementData.DeathCount++;
        achievementService.CheckAchievementProgress();
    }
    #endregion
}
