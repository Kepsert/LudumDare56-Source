using UnityEngine;

[CreateAssetMenu(fileName = "DeathAchievement", menuName = "Achievements/DeathAchievement", order = 4)]
public class DeathAchievementSO : AchievementSO
{
    [SerializeField] int _requiredAmountOfDeaths = 10;
    public int RequiredAmountOfDeaths => _requiredAmountOfDeaths;

    public override bool CheckUnlockCondition(AchievementData data)
    {
        return data.DeathCount >= _requiredAmountOfDeaths;
    }
}
