using UnityEngine;

public class AchievementSO : ScriptableObject
{
    [SerializeField] string _achievementId = "Ach_25Death";
    public string AchievementId => _achievementId;
    [SerializeField] string _achievementName = "TwentyFiver";
    public string AchievementName => _achievementName;
    [SerializeField] string _description = "Die 25 times on a single save file!";
    public string Description => _description;
    [SerializeField] Sprite _achievementIcon = null;
    public Sprite AchievementIcon => _achievementIcon;
    [HideInInspector]
    [SerializeField] bool _isUnlocked = false;
    public bool IsUnlocked => _isUnlocked;

    public virtual bool CheckUnlockCondition(AchievementData data)
    {
        return false;
    }

    public void Lock()
    {
        _isUnlocked = false;
    }

    public void Unlock()
    {
        _isUnlocked = true;
    }
}
