using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "LocalizationConfig", menuName = "Config/Localization", order = 4)]
public class LocalizationConfig : ScriptableObject
{
    [SerializeField] List<LocalizationMessageByKey> _localizationMessageList = new();
    [SerializeField] Dictionary<string, Dictionary<LanguageCode, string>> _dictionaryLocalizationMessageByMessageKey = new();
    public Dictionary<string, Dictionary<LanguageCode, string>> DictionaryLocalizationMessageByMessageKey => _dictionaryLocalizationMessageByMessageKey;

    public void Init()
    {
        foreach (LocalizationMessageByKey localizationMessageByKey in _localizationMessageList)
        {
            if (!_dictionaryLocalizationMessageByMessageKey.ContainsKey(localizationMessageByKey.MessageKey))
            {
                Dictionary<LanguageCode, string> dictionaryMessageByLanguageCode = new();
                foreach (LocalizationMessage message in localizationMessageByKey.LocalizationMessageList)
                {
                    if (!dictionaryMessageByLanguageCode.ContainsKey(message.LanguageCode))
                        dictionaryMessageByLanguageCode.TryAdd(message.LanguageCode, message.MessageValue);
                }

                _dictionaryLocalizationMessageByMessageKey.TryAdd(localizationMessageByKey.MessageKey, dictionaryMessageByLanguageCode);
            }
        }
    }
}

[System.Serializable]
public class LocalizationMessageByKey
{
    public string MessageKey;
    public List<LocalizationMessage> LocalizationMessageList;
}

[System.Serializable]
public class LocalizationMessage
{
    public LanguageCode LanguageCode;
    public string MessageValue;
}

public enum LanguageCode
{
    None = 0,
    En = 1,
    Nl = 2,
    De = 4,
    Fr = 8,
}