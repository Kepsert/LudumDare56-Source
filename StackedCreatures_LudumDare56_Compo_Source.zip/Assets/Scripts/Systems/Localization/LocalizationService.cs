using System;
using System.Collections.Generic;
using UnityEngine;

public class LocalizationService : MonoBehaviour
{
    [SerializeField] LocalizationConfig _localizationConfig = null;
    LanguageCode _currentLanguage = LanguageCode.En;
    public LanguageCode CurrentLanguage => _currentLanguage;

    private Dictionary<string, Dictionary<LanguageCode, string>> _localizedTexts = new();

    public event Action OnLocalizationChanged;

    void Awake()
    {
        if (_localizationConfig != null)
        {
            _localizationConfig.Init();
            LoadLocalization();
            GetLocalizationsForLanguage(_currentLanguage);
        }
        else
            Debug.LogWarning($"Missing localizationconfig on '{this.gameObject.name}'");
    }

    public void LoadLocalization()
    {
        _localizedTexts = _localizationConfig.DictionaryLocalizationMessageByMessageKey;
        Debug.Log($"Loaded localization for language '{_currentLanguage}'.");
    }

    public Dictionary<string, string> GetLocalizationsForLanguage(LanguageCode languageCode)
    {
        // Create a new dictionary to store the filtered localizations
        var filteredLocalizations = new Dictionary<string, string>();

        foreach (var entry in _localizedTexts)
        {
            // Check if the dictionary contains the requested language code
            if (entry.Value.TryGetValue(languageCode, out var message))
            {
                filteredLocalizations[entry.Key] = message;
            }
        }

        OnLocalizationChanged?.Invoke();

        return filteredLocalizations;
    }

    public string GetLocalizedText(string key)
    {
        if (_localizedTexts.TryGetValue(key, out var languageDictionary))
        {
            if (languageDictionary.TryGetValue(_currentLanguage, out var localizedText))
                return localizedText;
            else
            {
                Debug.LogWarning($"No localization found for key '{key}' in language '{_currentLanguage}'.");
                return key; // Fallback to key if not found
            }
        }
        else
        {
            Debug.LogWarning($"Key '{key}' not found in localization dictionary.");
            return key; // Fallback to key if not found
        }
    }

    public void SetCurrentLanguage(LanguageCode languageCode)
    {
        _currentLanguage = languageCode;
        GetLocalizationsForLanguage(_currentLanguage);
        Debug.Log($"Language changed to '{_currentLanguage}'.");
    }

    [ContextMenu("Swap Language To Nl")]
    public void SwapLanguageToDutch()
    {
        LocalizationService localizationService = ServiceLocator.GetService<LocalizationService>();
        Debug.Log(localizationService.GetLocalizedText("LocalizationTest"));
        localizationService.SetCurrentLanguage(LanguageCode.Nl);
        Debug.Log(localizationService.GetLocalizedText("LocalizationTest"));
    }
}
