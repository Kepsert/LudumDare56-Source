using System;
using System.Collections.Generic;
using UnityEngine;

public class DialogueService : MonoBehaviour
{
    Queue<DialogueLine> _dialogueQueue = new();
    Dialogue _currentDialogue;

    public event Action<DialogueLine> OnDialogueLineDisplayed;
    public event Action OnDialogueStarted;
    public event Action OnDialogueEnded;

    Dictionary<string, Animator> _dictionaryActorAnimatorByName = new();
    public Dictionary<string, Animator> DictionaryActorAnimatorByName => _dictionaryActorAnimatorByName;

    public void StartDialogue(Dialogue dialogue)
    {
        if (dialogue == null)
        {
            Debug.LogWarning("Tried to start a null dialogue");
            return;
        }

        _dialogueQueue.Clear();

        foreach (var line in dialogue.Lines)
            _dialogueQueue.Enqueue(line);

        _currentDialogue = dialogue;

        OnDialogueStarted?.Invoke();
        DisplayNextLine();
    }

    public void DisplayNextLine()
    {
        if (_dialogueQueue.Count == 0)
        {
            EndDialogue();
            return;
        }

        var currentLine = _dialogueQueue.Dequeue();
        OnDialogueLineDisplayed?.Invoke(currentLine);
    }

    void EndDialogue()
    {
        OnDialogueEnded?.Invoke();
        _currentDialogue = null;
    }

    public void SkipDialogue()
    {
        if (_currentDialogue != null)
            EndDialogue();
    }

    public void RegisterActor(string name, Animator animator)
    {
        if (!_dictionaryActorAnimatorByName.ContainsKey(name))
            _dictionaryActorAnimatorByName.TryAdd(name, animator);
        else
            Debug.Log($"Can't unregister actor with name '{name}' because it's already registered.");
    }

    public void UnregisterActor(string name)
    {
        if (_dictionaryActorAnimatorByName.ContainsKey(name))
            _dictionaryActorAnimatorByName.Remove(name);
        else
            Debug.Log($"Can't unregister actor with name '{name}' because it's not registered yet.");
    }

    public void ClearActorDictionary()
    {
        _dictionaryActorAnimatorByName.Clear(); 
    }
}
