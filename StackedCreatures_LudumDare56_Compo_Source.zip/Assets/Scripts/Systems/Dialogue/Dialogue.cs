using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Dialogue", menuName = "Dialogue/Dialogue", order = 6)]
public class Dialogue : ScriptableObject
{
    public string DialogueName;
    public List<DialogueLine> Lines;
}
