using System;
using UnityEngine;

[Serializable]
public class DialogueLine
{
    public string CharacterName;
    public string Text;
    public AudioClip VoiceClip;
    public Sprite CharacterSprite;
    public string ActorName;
    public string AnimationName;
}
