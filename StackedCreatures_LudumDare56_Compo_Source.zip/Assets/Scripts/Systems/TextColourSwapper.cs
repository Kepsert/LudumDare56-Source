using TMPro;
using UnityEngine;

public class TextColourSwapper : MonoBehaviour
{
    PaletteService PaletteService;

    [SerializeField] TMP_Text _text = null;

    void Start()
    {
        InitServices();
        InitRefs();

        PaletteService.OnPaletteSwap += OnPaletteSwap;

        _text.color = PaletteService.GetFontColor();
    }

    void InitServices()
    {
        PaletteService ??= ServiceLocator.GetService<PaletteService>();
    }

    void InitRefs()
    {
        if (_text == null)
            _text = GetComponent<TMP_Text>();
    }

    void OnPaletteSwap(Color color)
    {
        _text.color = color;
    }

    void OnDestroy()
    {
        PaletteService.OnPaletteSwap -= OnPaletteSwap;
    }
}
