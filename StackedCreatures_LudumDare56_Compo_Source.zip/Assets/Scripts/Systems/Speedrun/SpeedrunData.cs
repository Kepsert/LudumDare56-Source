using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SpeedrunData", menuName = "Speedrun/SpeedrunData", order = 1)]
public class SpeedrunData : ScriptableObject
{
    [SerializeField] private Dictionary<string, Dictionary<int, float>> _speedrunTimesByLevel = new();

    public Dictionary<int, float> GetTimesForLevel(string levelName)
    {
        if (_speedrunTimesByLevel.TryGetValue(levelName, out var timesBySlot))
        {
            return timesBySlot;
        }
        return null;
    }

    public void SetBestTime(string levelName, int saveSlot, float time)
    {
        if (!_speedrunTimesByLevel.ContainsKey(levelName))
        {
            _speedrunTimesByLevel[levelName] = new Dictionary<int, float>();
        }

        var timesBySlot = _speedrunTimesByLevel[levelName];

        if (timesBySlot.ContainsKey(saveSlot))
        {
            if (time < timesBySlot[saveSlot])
            {
                timesBySlot[saveSlot] = time;
            }
        }
        else
        {
            timesBySlot[saveSlot] = time;
        }
    }

    public float GetBestTime(string levelName, int saveSlot)
    {
        var timesBySlot = GetTimesForLevel(levelName);
        if (timesBySlot != null && timesBySlot.TryGetValue(saveSlot, out var bestTime))
        {
            return bestTime;
        }
        return -1f;
    }

    public void ClearLevelTime(string levelName, int saveSlot)
    {
        if (_speedrunTimesByLevel.TryGetValue(levelName, out var timesBySlot))
        {
            if (timesBySlot.ContainsKey(saveSlot))
            {
                timesBySlot.Remove(saveSlot);

                // Optionally, remove the level entry if it has no more times
                if (timesBySlot.Count == 0)
                {
                    _speedrunTimesByLevel.Remove(levelName);
                }
            }
        }
    }

    public IEnumerable<string> GetAllLevels()
    {
        return _speedrunTimesByLevel.Keys;
    }

    public SpeedrunSaveWrapper ToSaveWrapper()
    {
        return new SpeedrunSaveWrapper { Data = _speedrunTimesByLevel };
    }

    // Load the data from a wrapper
    public void FromSaveWrapper(SpeedrunSaveWrapper wrapper)
    {
        _speedrunTimesByLevel = wrapper.Data;
    }
}

[System.Serializable]
public class SpeedrunSaveWrapper
{
    public Dictionary<string, Dictionary<int, float>> Data;
}
