using System;
using UnityEngine;

public class SpeedrunService : MonoBehaviour
{
    [SerializeField] private SpeedrunData _speedrunData;

    private float _currentRunTime;
    private bool _isRunning;
    private int _currentSaveSlot = -1;

    public event Action<float> OnSpeedrunStart;
    public event Action<float> OnSpeedrunEnd;
    public event Action<string, float> OnNewBestTime;

    private void Update()
    {
        if (_isRunning)
        {
            _currentRunTime += Time.deltaTime;
        }
    }

    public void StartSpeedrun()
    {
        if (_currentSaveSlot.Equals(-1))
        {
            Debug.LogWarning("Can not process with speedrun action, set a saveslot first");
            return;
        }
        _currentRunTime = 0f;
        _isRunning = true;
        OnSpeedrunStart?.Invoke(_currentRunTime);
        Debug.Log("Speedrun started!");
    }

    public void StopSpeedrun(string levelName)
    {
        if (_currentSaveSlot.Equals(-1))
        {
            Debug.LogWarning("Can not process with speedrun action, set a saveslot first");
            return;
        }
        _isRunning = false;
        OnSpeedrunEnd?.Invoke(_currentRunTime);
        Debug.Log($"Speedrun ended! Time: {_currentRunTime} seconds");

        _speedrunData.SetBestTime(levelName, _currentSaveSlot, _currentRunTime);
        OnNewBestTime?.Invoke(levelName, _currentRunTime);
    }

    public float GetBestTime(string levelName)
    {
        if (_currentSaveSlot.Equals(-1))
        {
            Debug.LogWarning("Can not process with speedrun action, set a saveslot first");
            return 0;
        }
        return _speedrunData.GetBestTime(levelName, _currentSaveSlot);
    }

    public void ClearLevelTimeForSlot(string levelName)
    {
        if (_currentSaveSlot.Equals(-1))
        {
            Debug.LogWarning("Can not process with speedrun action, set a saveslot first");
            return;
        }
        _speedrunData.ClearLevelTime(levelName, _currentSaveSlot);
        Debug.Log($"Cleared time for level '{levelName}' and slot '{_currentSaveSlot}'");
    }

    public void ClearAllTimesForCurrentSlot()
    {
        if (_currentSaveSlot.Equals(-1))
        {
            Debug.LogWarning("Can not process with speedrun action, set a saveslot first");
            return;
        }
        var allLevels = _speedrunData.GetAllLevels();

        foreach (var level in allLevels)
        {
            _speedrunData.ClearLevelTime(level, _currentSaveSlot);
        }

        Debug.Log($"Cleared all times for save slot '{_currentSaveSlot}'");
    }

    public void SetSaveSlot(int slot)
    {
        if (slot <= 0)
        {
            Debug.LogWarning("Save slot has to be 1 or higher");
            return;
        }
        _currentSaveSlot = slot;
    }

    #region SpeedrunServiceTests
    [ContextMenu("StartSpeedrunTimer")]
    public void TestStartSpeedrunTimer()
    {
        SpeedrunService speedrunService = ServiceLocator.GetService<SpeedrunService>();
        speedrunService.SetSaveSlot(1);
        speedrunService.StartSpeedrun();
    }

    [ContextMenu("EndSpeedrunTimer")]
    public void TestEndSpeedrunTimer()
    {
        SpeedrunService speedrunService = ServiceLocator.GetService<SpeedrunService>();
        speedrunService.SetSaveSlot(1);
        speedrunService.StopSpeedrun("Level1");
    }

    [ContextMenu("GetBestTime")]
    public void TestGetBestTime()
    {
        SpeedrunService speedrunService = ServiceLocator.GetService<SpeedrunService>();
        speedrunService.SetSaveSlot(1);
        float bestTime = speedrunService.GetBestTime("Level1");
        if (bestTime > 0)
            Debug.Log($"Best time for level 1 is '{speedrunService.GetBestTime("Level1")}'");
        else
            Debug.Log($"There is no best time for level 1");
    }

    [ContextMenu("ClearTime")]
    public void TestClearTime()
    {
        SpeedrunService speedrunService = ServiceLocator.GetService<SpeedrunService>();
        speedrunService.SetSaveSlot(1);
        speedrunService.ClearLevelTimeForSlot("Level1");
    }
    #endregion
}
