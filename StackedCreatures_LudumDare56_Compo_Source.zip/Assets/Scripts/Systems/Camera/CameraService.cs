using Cinemachine;
using DG.Tweening;
using System.Collections;
using UnityEngine;

public class CameraService : MonoBehaviour
{
    CinemachineVirtualCamera _activeCamera;
    CinemachineVirtualCamera _lastCamera;
    Coroutine _blendCoroutine;
    Coroutine _shakeCoroutine;
    Tween _moveTween;

    public void FollowNewTarget(Transform newTarget)
    {
        _activeCamera.Follow = newTarget;
    }

    public void SetActiveCamera(CinemachineVirtualCamera camera)
    {
        if (_activeCamera != null)
            _activeCamera.Priority = 0;

        _lastCamera = _activeCamera;
        _activeCamera = camera;
        _activeCamera.Priority = 10;
    }

    public void TransitionToCamera(CinemachineVirtualCamera newCamera, float transitionDuration)
    {
        CinemachineBrain brain = _activeCamera.GetComponent<CinemachineBrain>();

        if (brain != null && _activeCamera != null)
            _blendCoroutine = StartCoroutine(BlendToCamera(brain, newCamera, transitionDuration));
        else
            SetActiveCamera(newCamera);
    }

    IEnumerator BlendToCamera(CinemachineBrain brain, CinemachineVirtualCamera newCamera, float duration)
    {
        brain.m_DefaultBlend.m_Time = duration;
        SetActiveCamera(newCamera);
        yield return new WaitForSeconds(duration);

        brain.m_DefaultBlend.m_Time = 0f;
    }

    public void StopBlend()
    {
        StopCoroutine(_blendCoroutine);
        _lastCamera.GetComponent<CinemachineBrain>().m_DefaultBlend.m_Time = 0f;
    }

    public void ShakeCamera(float amplitude, float frequency, float duration)
    {
        CinemachineBasicMultiChannelPerlin noise = _activeCamera.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();

        if (noise != null)
        {
            noise.m_AmplitudeGain = amplitude;
            noise.m_FrequencyGain = frequency;

            _shakeCoroutine = StartCoroutine(StopCameraShake(noise, duration));
        }
        else
            Debug.LogWarning($"Active camera does not have a noise components.");
    }

    IEnumerator StopCameraShake(CinemachineBasicMultiChannelPerlin noise, float duration)
    {
        yield return new WaitForSeconds(duration);
        noise.m_AmplitudeGain = 0f;
        noise.m_FrequencyGain = 0f;
    }

    public void StopCameraShake()
    {
        StopCoroutine(_shakeCoroutine);
        CinemachineBasicMultiChannelPerlin noise = _activeCamera.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
        noise.m_AmplitudeGain = 0f;
        noise.m_FrequencyGain = 0f;
    }

    public void ZoomCamera(float targetFOV, float duration)
    {
        if (_activeCamera != null)
            StartCoroutine(ZoomEffect(targetFOV, duration));
    }

    IEnumerator ZoomEffect(float targetFOV, float duration)
    {
        float initialFOV = _activeCamera.m_Lens.FieldOfView;
        float time = 0f;

        while (time < duration)
        {
            _activeCamera.m_Lens.FieldOfView = Mathf.Lerp(initialFOV, targetFOV, time / duration);
            time += Time.deltaTime;
            yield return null;
        }

        _activeCamera.m_Lens.FieldOfView = targetFOV;
    }

    public void MoveCameraTween(Vector3 newPos, float duration, Ease easeType = Ease.InSine)
    {
        if (_activeCamera != null)
           _moveTween = _activeCamera.transform.DOMove(newPos, duration).SetEase(easeType);
        else
            Debug.LogWarning("Set an active camera before trying to move");
    }

    public void StopMoveCamera()
    {
        _moveTween.Kill();
    }
}
