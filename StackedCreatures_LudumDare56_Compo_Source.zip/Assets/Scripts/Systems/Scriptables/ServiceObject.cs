using System;
using UnityEngine;

[CreateAssetMenu(fileName = "ServiceObject", menuName = "Service", order = 0)]
public class ServiceObject : ScriptableObject
{
    public string serviceName;
    public GameObject servicePrefab;
}
