using System;
using System.Collections.Generic;
using UnityEngine;


public class TimerService : MonoBehaviour
{
    private List<TimerModel> _timers = new();
    private List<TimerCheckModel> _checkTimers = new();

    private Dictionary<string, TimeVariableModel> _timeVariables = new Dictionary<string, TimeVariableModel>();

    public float GetVariable(string key, float maxValue = 1)
    {
        if (_timeVariables.TryGetValue(key, out var model))
        {
            return model.Value;
        }

        var newModel = new TimeVariableModel()
        {
            Id = key,
            Value = 0,
            MaxValue = maxValue
        };
        _timeVariables.Add(key, newModel);
        return newModel.Value;
    }

    public void RemoveVariable(string key)
    {
        _timeVariables.Remove(key);
    }

    public Guid RemoveTimer(Guid guid)
    {
        _timers.RemoveAll(t => t.Guid == guid);
        return Guid.Empty;
    }

    public void RemoveTimer(string id)
    {
        _timers.RemoveAll(t => t.Id == id);
    }

    public Guid AddTimer(float time, Action onComplete, string id = "")
    {
        var guid = Guid.NewGuid();
        _timers.Add(new TimerModel()
        {
            Time = time,
            OnComplete = onComplete,
            Guid = guid,
            Id = string.IsNullOrEmpty(id) ? guid.ToString() : id

        });

        return guid;
    }

    public Guid AddCheck(Func<bool> toComplete, Action onComplete, bool performEveryFrame = false, string id = "")

    {
        var guid = Guid.NewGuid();

        _checkTimers.Add(new TimerCheckModel()
        {
            Guid = guid,
            ToComplete = toComplete,
            OnComplete = onComplete,
            PerformEveryFrame = performEveryFrame,
            Id = string.IsNullOrEmpty(id) ? guid.ToString() : id
        });
        return guid;
    }

    public Guid RemoveCheck(Guid guid)
    {
        _checkTimers.RemoveAll(t => t.Guid == guid);
        return Guid.Empty;
    }
    public Guid RemoveCheck(string id)
    {
        _checkTimers.RemoveAll(t => t.Id == id);
        return Guid.Empty;
    }

    private void Update()
    {
        for (int i = 0; i < _timers.Count; ++i)
        {
            if (_timers[i].IsPaused)
                continue;

            _timers[i].ElapsedTime += Time.deltaTime;
            if (_timers[i].ElapsedTime >= _timers[i].Time)
            {
                _timers[i].IsDone = true;
                _timers[i].OnComplete();
            }
        }

        foreach (var checkModel in _checkTimers)
        {
            if (checkModel.ToComplete())
            {
                checkModel.IsDone = true;

                if (!checkModel.PerformEveryFrame)
                {
                    checkModel.OnComplete();
                }
            }
            else if (checkModel.PerformEveryFrame)
            {
                checkModel.OnComplete();
            }
        }

        foreach (var (key, model) in _timeVariables)
        {
            model.Value += Time.deltaTime;
            if (model.Value > model.MaxValue + 1)
            {
                model.IsDone = true;
            }
        }

        _timers.RemoveAll(t => t.IsDone);
        _checkTimers.RemoveAll(t => t.IsDone);
    }

    public void ClearTimers()
    {
        _timers.Clear();
    }

    public void PauseTimer(Guid guid)
    {
        Debug.Log("Pausing Timer");
        var timer = _timers.Find(t => t.Guid == guid);
        if (timer != null)
        {
            Debug.Log($"Pausing Timer {timer.Guid}");

            timer.IsPaused = true;
        }
    }

    public void UnPauseTimer(Guid guid)
    {
        Debug.Log("Unpausing Timer");
        var timer = _timers.Find(t => t.Guid == guid);
        if (timer != null)
        {
            timer.IsPaused = false;
        }
    }


    public class TimerModel
    {
        public float Time { get; set; }
        public float ElapsedTime { get; set; }
        public Action OnComplete { get; set; }
        public bool IsDone { get; set; }
        public Guid Guid { get; set; }
        public bool IsPaused { get; set; }
        public string Id { get; set; }
    }

    public class TimerCheckModel
    {
        public Func<bool> ToComplete { get; set; }
        public Action OnComplete { get; set; }
        public Guid Guid { get; set; }
        public bool IsDone { get; set; }
        public bool PerformEveryFrame { get; set; }
        public string Id { get; set; }
    }

    public class TimeVariableModel
    {
        public float Value { get; set; }
        public string Id { get; set; }
        public float MaxValue { get; set; }
        public bool IsDone { get; set; }
    }
}
