using LDtkUnity;
using UnityEngine;

public class RotateLDTkObject : MonoBehaviour, ILDtkImportedFields
{
    [SerializeField] Rotation _rotation = Rotation.Up;
    Collider2D _collider;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _rotation = fields.GetEnum<Rotation>("Rotation");

        switch (_rotation)
        {
            case Rotation.Up: this.transform.eulerAngles = new Vector3(0, 0, 0); break;
            case Rotation.Down: this.transform.eulerAngles = new Vector3(0, 0, 180); break;
            case Rotation.Left: this.transform.localRotation = Quaternion.Euler(0, 0, 90); _collider = GetComponent<Collider2D>(); _collider.enabled = false; break;
            case Rotation.Right: this.transform.localRotation = Quaternion.Euler(0, 0, 270); _collider = GetComponent<Collider2D>(); _collider.enabled = false; break;
        }
    }
}
