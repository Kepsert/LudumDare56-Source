using TMPro;
using UnityEngine;

public class LocalizationText : MonoBehaviour
{
    LocalizationService _localizationService;

    [SerializeField] TMP_Text _text = null;
    [SerializeField] string _localizationKey = "LocalizationKey";

    private void Awake()
    {
        if (_localizationService == null)
            _localizationService = ServiceLocator.GetService<LocalizationService>();

        _text.text = _localizationService.GetLocalizedText(_localizationKey);
    }

    void OnEnable()
    {
        _localizationService.OnLocalizationChanged += OnLocalizationChanged;        
    }

   void OnLocalizationChanged()
    {
        _text.text = _localizationService.GetLocalizedText(_localizationKey);
    }

    void OnDisable()
    {
        if (_localizationService != null)
            _localizationService.OnLocalizationChanged -= OnLocalizationChanged;
    }
}
