using LDtkUnity;
using UnityEngine;

public class LevelController : MonoBehaviour, ILDtkImportedFields
{
    AudioService AudioService;

    [SerializeField] int _gameplayTrack;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _gameplayTrack = fields.GetInt("GameplayTrack");
    }

    void Awake()
    {
        AudioService ??= ServiceLocator.GetService<AudioService>();

        AudioService.PlaySoundtrack("Gameplay" + _gameplayTrack);
    }
}
