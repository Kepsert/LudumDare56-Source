using Cinemachine;
using LDtkUnity;
using UnityEngine;
using UnityEngine.Tilemaps;

public class BaseLevel : MonoBehaviour, ILDtkImportedLevel
{
    [SerializeField] Transform _top = null;
    [SerializeField] Transform _bottom = null;
    [SerializeField] Transform _left = null;
    [SerializeField] Transform _right = null;

    PolygonCollider2D _polygonCollider2D;
    CinemachineVirtualCamera _cineCam;

    [SerializeField] Material _paletteSwapMat = null;

    public void OnLDtkImportLevel(Level level)
    {
        _polygonCollider2D = GetComponent<PolygonCollider2D>();
        var utilities = transform.Find("Utilities");

        if (utilities == null)
        {
            Debug.LogWarning($"No Utilities in level '{level.Iid}'");
            return;
        }

        var confiner = utilities.GetComponentInChildren<CinemachineConfiner2D>();
        if (confiner == null)
        {
            Debug.LogWarning($"No confiner in '{level.Iid}'");
            return;
        }

        confiner.m_BoundingShape2D = GetComponent<PolygonCollider2D>();
        _cineCam = GetComponentInChildren<CinemachineVirtualCamera>();
        _cineCam.m_Follow = (FindObjectOfType<PlayerController>().transform);

        var collider = transform.GetComponent<Collider2D>();
        var extents = collider.bounds.extents;
        _top.position = collider.bounds.center + new Vector3(0, extents.y + 0.5f, 0);
        _left.position = collider.bounds.center + new Vector3(-extents.x - 0.5f, 0, 0);
        _right.position = collider.bounds.center + new Vector3(extents.x + 0.5f, 0, 0);
        _bottom.position = collider.bounds.center + new Vector3(0, -extents.y - 2.5f, 0);

        var points = _polygonCollider2D.points;
        _polygonCollider2D.points = new[]
        {
            points[0] + new Vector2(1, -1),
            points[1] + new Vector2(1, 1),
            points[2] + new Vector2(-1, 1),
            points[3] + new Vector2(-1, -1),
        };

        foreach (TilemapRenderer renderer in this.GetComponentsInChildren<TilemapRenderer>())
            renderer.material = _paletteSwapMat;

        var spriterenderers = GetComponentsInChildren<SpriteRenderer>();
        foreach (SpriteRenderer renderer in spriterenderers)
            renderer.material = _paletteSwapMat;
    }
}
