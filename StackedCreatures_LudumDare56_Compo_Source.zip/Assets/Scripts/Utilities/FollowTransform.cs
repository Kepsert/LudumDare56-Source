using UnityEngine;

public class FollowTransform : MonoBehaviour
{
    [SerializeField] FollowTransformConfig _config = null;
    [SerializeField] SpriteRenderer _renderer = null;

    Transform _followTarget;
    bool _isFollowing;

    ITriggerable _triggerable;

    public void StartFollowing(Transform target, ITriggerable triggerable = null)
    {
        _followTarget = target;
        _isFollowing = true;
        _triggerable = triggerable;
    }

    private void FixedUpdate()
    {
        if (_isFollowing && _followTarget != null)
        {
            Vector3 targetPosition = _followTarget.position;

            transform.position = Vector3.Lerp(transform.position, targetPosition, _config.FollowSpeed * Time.deltaTime);

            if (_triggerable != null)
                if (Vector3.Distance(transform.position, _followTarget.position) < _config.FinalTargetDistance)
                {
                    _triggerable.Trigger();
                    _renderer.enabled = false;
                }
        }
    }

    public void StopFollowing()
    {
        _isFollowing = false;
        _followTarget = null;
        _triggerable = null;
    }

    public void SetNewFollowTarget(Transform target)
    {
        _followTarget = target;
    }
}
