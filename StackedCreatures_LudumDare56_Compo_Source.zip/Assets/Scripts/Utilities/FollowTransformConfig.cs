using UnityEngine;

[CreateAssetMenu(fileName = "FollowTransform", menuName = "Utilities/FollowTransform", order = 15)]
public class FollowTransformConfig : ScriptableObject
{
    [SerializeField] float _followDistance = 1.5f;
    public float FollowDistance => _followDistance;
    [SerializeField] float _followSpeed = 5f;
    public float FollowSpeed => _followSpeed;
    [SerializeField] float _finalTargetDistance = .1f;
    public float FinalTargetDistance => _finalTargetDistance; 
}
