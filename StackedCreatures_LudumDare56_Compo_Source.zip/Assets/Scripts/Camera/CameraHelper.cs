using Cinemachine;
using UnityEngine;

public class CameraHelper : MonoBehaviour
{
    CameraService CameraService;

    [SerializeField] CinemachineVirtualCamera _cinemachineCamera = null;

    void Awake()
    {
        InitServices();

        CameraService.SetActiveCamera(_cinemachineCamera);
    }

    void InitServices()
    {
        CameraService ??= ServiceLocator.GetService<CameraService>();
    }
}
