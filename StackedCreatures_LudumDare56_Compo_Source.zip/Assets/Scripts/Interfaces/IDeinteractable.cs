using UnityEngine;

public interface IDeinteractable
{
    InteractableType InteractableType { get; }
    void Deinteract(Transform transform = null);
}
