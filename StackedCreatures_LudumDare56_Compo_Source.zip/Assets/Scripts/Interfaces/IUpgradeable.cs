public interface IUpgradeable
{
    CreatureUpgradeTypes GetUpgradeType();
}
