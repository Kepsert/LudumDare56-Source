public interface IKiller
{
    KillerType KillerType { get; }
}

public enum KillerType
{
    Spike = 0,
}
