using UnityEngine;

public interface IInteractable
{
    InteractableType InteractableType { get; }

    void Interact(Transform transform = null);
    Transform GetTransform();
}

public enum InteractableType
{
    Finish = 0,
    FinishTrigger = 1,
    BounceShroom = 2,
}