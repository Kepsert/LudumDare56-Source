public interface ITriggerable
{
    void Trigger();
    ITriggerable GetTrigger();
}
