using UnityEngine;

public interface ICollectable
{
    CollectableType CollectableType { get; }
    CollectableType Collect(Transform transform = null);
}

public enum CollectableType
{
    Jimmy = 0,
    Key = 1,
}
