using UnityEngine;

public interface IUsable
{
    void Use(Transform point, ITriggerable triggerable);
}
