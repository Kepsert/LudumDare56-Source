using UnityEngine;

public class GemKey : MonoBehaviour, ICollectable, IUsable
{
    [SerializeField] CollectableType _type = CollectableType.Key;
    [SerializeField] ParticleSystem _particleSystem = null;
    [SerializeField] SpriteRenderer _spriteRenderer = null;
    [SerializeField] Collider2D _trigger = null;
    [SerializeField] HoverUpDownEffect _hoverUpDownEffect = null;
    [SerializeField] FollowTransform _followTransform = null;
    public CollectableType CollectableType => _type;

    public CollectableType Collect(Transform transform = null)
    {
        _particleSystem.Stop();
        _trigger.enabled = false;
        _hoverUpDownEffect.KillSequence();

        if (transform != null)
            _followTransform.StartFollowing(transform);

        return _type;
    }

    public void Use(Transform point, ITriggerable triggerable)
    {
        _followTransform.StartFollowing(point, triggerable);
    }
}
