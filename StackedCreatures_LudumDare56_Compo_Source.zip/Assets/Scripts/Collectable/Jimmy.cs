using UnityEngine;

public class Jimmy : MonoBehaviour, ICollectable, IUpgradeable
{
    [SerializeField] CollectableType _type = CollectableType.Jimmy;
    [SerializeField] CreatureUpgradeTypes _upgradeType = CreatureUpgradeTypes.None;
    [SerializeField] SpriteRenderer _spriteRenderer = null;
    [SerializeField] Collider2D _trigger = null;
    [SerializeField] ParticleSystem _particleSystem = null;
    public CollectableType CollectableType => _type;

    public CollectableType Collect(Transform transform = null)
    {
        _spriteRenderer.enabled = false;
        _trigger.enabled = false;
        _particleSystem.Stop();

        return _type;
    }

    public CreatureUpgradeTypes GetUpgradeType()
    {
        return _upgradeType;
    }
}
