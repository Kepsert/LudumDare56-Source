using UnityEngine;

public class Spike : MonoBehaviour, IKiller
{
    [SerializeField] KillerType _type = KillerType.Spike;
    public KillerType KillerType => _type;
}
