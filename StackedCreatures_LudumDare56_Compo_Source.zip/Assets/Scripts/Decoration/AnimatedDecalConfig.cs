using UnityEngine;

[CreateAssetMenu(fileName = "AnimatedDecal", menuName = "AnimatedDecal/AnimatedDecal", order = 15)]
public class AnimatedDecalConfig : ScriptableObject
{
    [SerializeField] float _activateDelay = 2f;
    public float ActivateDelay => _activateDelay;
    [SerializeField] float _activeAnimDuration = 0.4f;
    public float ActiveAnimDuration => _activeAnimDuration;
    [SerializeField] string _activeAnimTag = "Active";
    public string ActiveAnimTag => _activeAnimTag;

    [SerializeField] float _movementSpeed = 1f;
    public float MovementSpeed => _movementSpeed;
    [SerializeField] float _changeDirectionTime = 2f;
    public float ChangeDirectionTime => _changeDirectionTime;
    [SerializeField] string _soundName = "";
    public string SoundName => _soundName;
}
