using UnityEngine;

public class FlyDecal : MonoBehaviour
{
    [SerializeField] CircleCollider2D _boundaryCollider = null;

    [SerializeField] AnimatedDecalConfig _config = null;

    Vector3 _targetPosition;
    float _timer;

    void Start()
    {
        _boundaryCollider.transform.SetParent(null);
        SetRandomTargetPosition();
    }

    void FixedUpdate()
    {
        MoveTowardsTarget();

        _timer += Time.deltaTime;
        if (_timer >= _config.ChangeDirectionTime)
        {
            SetRandomTargetPosition();
            _timer = 0;
        }
    }

    private void MoveTowardsTarget()
    {
        float step = _config.MovementSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, _targetPosition, step);
    }

    void SetRandomTargetPosition()
    {
        Vector2 randomDirection = Random.insideUnitCircle * _boundaryCollider.radius;
        _targetPosition = new Vector3(randomDirection.x + _boundaryCollider.transform.position.x,
            randomDirection.y + _boundaryCollider.transform.position.y,
            transform.position.z);
    }
}
