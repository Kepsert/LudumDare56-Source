using UnityEngine;

public class StoryController : MonoBehaviour
{
    StoryService StoryService;
    AudioService AudioService;

    [SerializeField] StoryConfig _storyConfig = null;

    [SerializeField] string _musicToPlay = string.Empty;

    void Start()
    {
        InitServices();

        StoryService.StartNewStory(_storyConfig);
        if (string.IsNullOrEmpty(_musicToPlay))
            AudioService.StopSoundtrack();
        else
            AudioService.PlaySoundtrack(_musicToPlay);
    }

    void InitServices()
    {
        StoryService ??= ServiceLocator.GetService<StoryService>();
        AudioService ??= ServiceLocator.GetService<AudioService>();
    }
}
