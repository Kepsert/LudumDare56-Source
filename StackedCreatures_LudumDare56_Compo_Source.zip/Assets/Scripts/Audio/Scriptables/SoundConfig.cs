using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

[CreateAssetMenu(fileName = "SoundConfig", menuName = "Config/Sound", order = 3)]
public class SoundConfig : ScriptableObject
{
    [SerializeField] private SoundConfiguration[] _sfxConfigurations;
    readonly private Dictionary<string, SoundConfiguration> _dictionarySfxConfigByName = new();
    public Dictionary<string, SoundConfiguration> DictionarySfxConfigByName => _dictionarySfxConfigByName;

    [SerializeField] private SoundConfiguration[] _musicConfigurations;
    readonly private Dictionary<string, SoundConfiguration> _dictionaryMusicConfigByName = new();
    public Dictionary<string, SoundConfiguration> DictionaryMusicConfigByName => _dictionaryMusicConfigByName;

    [SerializeField] private AudioTypeConfig[] _audioTypeConfigurations;
    readonly private Dictionary<AudioType, AudioTypeConfig> _dictionaryAudioTypeConfigByType = new();
    public Dictionary<AudioType, AudioTypeConfig> DictionaryAudioTypeConfigByType => _dictionaryAudioTypeConfigByType;

    public void Init()
    {
        foreach (var config in _sfxConfigurations)
        {
            if (!_dictionarySfxConfigByName.ContainsKey(config.soundName))
                _dictionarySfxConfigByName.TryAdd(config.soundName, config);
        }

        foreach (var config in _musicConfigurations)
        {
            if (!_dictionaryMusicConfigByName.ContainsKey(config.soundName))
                _dictionaryMusicConfigByName.TryAdd(config.soundName, config);
        }

        foreach (var config in _audioTypeConfigurations)
        {
            if (!_dictionaryAudioTypeConfigByType.ContainsKey(config.audioType))
                _dictionaryAudioTypeConfigByType.TryAdd(config.audioType, config);
        }
    }
}

[Serializable]
public class SoundConfiguration
{
    public string soundName;
    public AudioType audioType;
    public bool randomise;
    public ClipsConfiguration[] sounds;
}

[Serializable]
public class ClipsConfiguration
{
    public AudioClip sound;
    public float volume = 1;
    public bool loop = false;
}

[Serializable]
public class AudioTypeConfig
{
    public AudioType audioType;
    public AudioMixerGroup audioMixerGroup;
    public bool fade = false;
    public float fadeDuration = 0.75f;
}

public enum AudioType
{
    Music = 0,
    Sfx = 1,
}
