using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Audio;

public class AudioService : MonoBehaviour
{
    [SerializeField] AudioMixer _audioMixer = null;
    [SerializeField] SoundConfig _soundConfig;
    List<AudioSources> audioSources = new();

    string _lastSoundtrackName;

    private void Awake()
    {
        if (_soundConfig == null)
            return;

        _soundConfig.Init();
    }

    void Start()
    {
        float masterVolume = PlayerPrefs.HasKey("MasterVolume") ? PlayerPrefs.GetFloat("MasterVolume") : 1f;
        Debug.Log("Initiating Master Volume");
        AdjustMasterVolume(masterVolume);
        float musicVolume = PlayerPrefs.HasKey("MusicVolume") ? PlayerPrefs.GetFloat("MusicVolume") : 2f;
        AdjustMusicVolume(musicVolume);
        float sfxVolume = PlayerPrefs.HasKey("SfxVolume") ? PlayerPrefs.GetFloat("SfxVolume") : 2f;
        AdjustSfxVolume(sfxVolume);
    }

    public void PlaySoundtrack(string soundName)
    {
        if (soundName.Equals(_lastSoundtrackName))
            return;
        if (_soundConfig == null)
            return;
        if (!_soundConfig.DictionaryMusicConfigByName.ContainsKey(soundName))
            return;

        var soundConfig = _soundConfig.DictionaryMusicConfigByName[soundName];
        if (soundConfig == null)
            return;

        AudioType type = soundConfig.audioType;
        if (!CheckIfThereIsFreeAudioSource(type))
            CreateFreeAudioSource(type);

        var soundtrackSource = audioSources.FirstOrDefault(x => x.type == type);
        if (!soundtrackSource.audioSource)
            return;

        int index = 0;
        if (soundConfig.randomise)
            index = GetRandomIndex(soundConfig);

        var clip = soundConfig.sounds[index];

        soundtrackSource.currentlyPlaying = true;
        soundtrackSource.soundName = soundName;
        PlaySoundMain(soundtrackSource.audioSource, clip.sound, soundConfig.audioType, clip.volume, clip.loop, (string.IsNullOrEmpty(_lastSoundtrackName)) ? false : _soundConfig.DictionaryAudioTypeConfigByType[soundConfig.audioType].fade);
        _lastSoundtrackName = soundName;
    }

    public void StopSoundtrack()
    {
        var soundtracksource = audioSources.FirstOrDefault(x => x.currentlyPlaying == true);
        if (soundtracksource == null)
            return;
        AudioSource source = soundtracksource.audioSource;
        if (source == null)
            return;

        source.DOFade(0, _soundConfig.DictionaryAudioTypeConfigByType[AudioType.Music].fadeDuration).OnComplete(() =>
        {
            _lastSoundtrackName = string.Empty;
            source.Stop();
        });
    }

    bool CheckIfThereIsFreeAudioSource(AudioType type, string dontStopSoundName = "")
    {
        var audioMixerGroup = _soundConfig.DictionaryAudioTypeConfigByType[type].audioMixerGroup;
        return audioSources.Any(x => x.audioSource.isPlaying == false && type.Equals(x.type) && !string.Equals(x.soundName, dontStopSoundName) && x.audioMixerGroup == audioMixerGroup);
    }

    void CreateFreeAudioSource(AudioType type)
    {
        var source = this.AddComponent<AudioSource>();
        var audioMixerGroup = _soundConfig.DictionaryAudioTypeConfigByType[type].audioMixerGroup;
        AudioSources sourceSettings = new AudioSources(type, source, audioMixerGroup);
        audioSources.Add(sourceSettings);
    }

    void PlaySoundMain(AudioSource source, AudioClip clip, AudioType type, float volume = 1, bool loop = true, bool fade = true)
    {
        if (!fade)
        {
            source.Stop();
            source.clip = clip;
            source.volume = volume;
            source.loop = loop;
            source.Play();
            return;
        }

        source.DOKill();

        source.DOFade(0, _soundConfig.DictionaryAudioTypeConfigByType[type].fadeDuration).OnComplete(() =>
        {
            source.Stop();
            source.clip = clip;
            source.loop = loop;
            source.Play();
            source.DOFade(volume, _soundConfig.DictionaryAudioTypeConfigByType[type].fadeDuration);
        });
    }

    public void StopSound(string soundName)
    {
        if (CheckIfAudioSourcesIsNull())
            return;
        var sound = audioSources.FirstOrDefault(x => string.Equals(x.soundName, soundName));
        if (sound == null)
            return;
        sound.currentlyPlaying = false;
        sound.audioSource.Stop();
    }

    public void StopSoundWithNameAndType(string soundName, AudioType type, bool fade = false)
    {
        if (CheckIfAudioSourcesIsNull())
            return;
        var sound = audioSources.FirstOrDefault(x => string.Equals(x.soundName, soundName));
        if (sound == null)
            return;
        var fadeDuration = _soundConfig.DictionaryAudioTypeConfigByType[type].fadeDuration;
        if (fade)
            sound.audioSource.DOFade(0, fadeDuration).OnComplete(() => StopAudioSource(sound.audioSource));
        else
            StopAudioSource(sound.audioSource);
        sound.currentlyPlaying = false;
    }

    public void PlaySfxSound(string soundName, AudioType audioType)
    {
        if (_soundConfig == null)
            return;

        if (!_soundConfig.DictionarySfxConfigByName.ContainsKey(soundName))
        {
            Debug.LogWarning($"Soundname '{soundName}' does not exist in the Sfx Config");
            return;
        }
        else if (_soundConfig.DictionarySfxConfigByName[soundName].sounds.Length == 0)
        {
            Debug.LogWarning($"Soundname '{soundName}' exists in the Sfx config but doesn't have any audioclips attached.");
            return;
        }

        if (!CheckIfThereIsFreeAudioSource(audioType))
        {
            CreateFreeAudioSource(audioType);
        }
        var SFXSource = audioSources.FirstOrDefault(x => x.type == audioType && !x.audioSource.isPlaying);
        if (!SFXSource.audioSource)
            return;

        if (!_soundConfig.DictionarySfxConfigByName.ContainsKey(soundName))
            return;

        var soundConfig = _soundConfig.DictionarySfxConfigByName[soundName];

        if (soundConfig == null)
            return;

        if (SFXSource.audioSource.isPlaying && SFXSource.soundName == soundName)
            return;

        int index = 0;
        if (soundConfig.randomise)
            index = GetRandomIndex(soundConfig);
        var clip = soundConfig.sounds[index];

        SFXSource.soundName = soundConfig.soundName;
        SFXSource.currentlyPlaying = true;

        PlaySoundMain(SFXSource.audioSource, clip.sound, audioType, clip.volume, clip.loop, _soundConfig.DictionaryAudioTypeConfigByType[soundConfig.audioType].fade);
        StartCoroutine(SetSFXToNotPlaying(SFXSource, clip.sound));
    }

    IEnumerator SetSFXToNotPlaying(AudioSources SFXSource, AudioClip clip)
    {
        yield return new WaitForSeconds(clip.length);
        SFXSource.currentlyPlaying = false;
    }

    void StopAudioSource(AudioSource source)
    {
        source.Stop();
        source.clip = null;
    }

    bool CheckIfAudioSourcesIsNull()
    {
        return (audioSources == null);
    }

    int GetRandomIndex(SoundConfiguration config)
    {
        return Random.Range(0, config.sounds.Length);
    }

    public void AdjustMasterVolume(float value)
    {
        float dB = value > 0 ? Mathf.Log10(value) * 20 : -80f;
        _audioMixer.SetFloat("MasterVolume", dB);
        PlayerPrefs.SetFloat("MasterVolume", value);
        Debug.Log("Changing Master Volume To: " + value);
    }

    public void AdjustMusicVolume(float value)
    {
        value /= 10;
        float dB = value > 0 ? Mathf.Log10(value) * 20 : -80f;
        _audioMixer.SetFloat("MusicVolume", dB);
        PlayerPrefs.SetFloat("MusicVolume", value * 10);
        Debug.Log("Changing Music Volume To: " + value);
    }

    public void AdjustSfxVolume(float value)
    {
        value /= 10;
        float dB = value > 0 ? Mathf.Log10(value) * 20 : -80f;
        _audioMixer.SetFloat("SfxVolume", dB);
        _audioMixer.SetFloat("UIVolume", dB);
        PlayerPrefs.SetFloat("SfxVolume", value * 10);
        Debug.Log("Changing Sfx Volume To: " + value);
    }
}

[System.Serializable]
public class AudioSources
{
    public string soundName;
    public AudioType type;
    public AudioSource audioSource;
    public bool currentlyPlaying;
    public AudioMixerGroup audioMixerGroup;
    public AudioSources(AudioType type, AudioSource audioSource, AudioMixerGroup audioMixerGroup)
    {
        this.type = type;
        this.audioSource = audioSource;
        this.audioMixerGroup = audioMixerGroup;
        audioSource.outputAudioMixerGroup = this.audioMixerGroup;
    }
}