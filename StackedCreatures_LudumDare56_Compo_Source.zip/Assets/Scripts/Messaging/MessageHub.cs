﻿using System;
using Object = UnityEngine.Object;

namespace Messaging
{
    public class MessageClass
    {
        public int Token { get; private set; }
        public readonly Action<IMessageBase> Message;

        public MessageClass(Action<IMessageBase> message, int token)
        {
            Message = message;
            Token = token;
        }
        
    }
    public class MessageHub
    {
        private static readonly MessageHubService MessageHubService = new MessageHubService();
        
        public static void ClearListeners()
        {
            MessageHubService.ClearListeners();
        }

        public static void Unsubscribe<T>(Object token) where T : IMessageBase
        {
            MessageHubService.Unsubscribe<T>(token);
        }

        public static void Unsubscribe<T>(int instanceId) where T : IMessageBase
        {
            MessageHubService.Unsubscribe<T>(instanceId);
        }

        public static void Subscribe<T>(Object monoBehaviour, Action<T> listener) where T : IMessageBase
        {
            MessageHubService.Subscribe(monoBehaviour, listener);
        }

        public static void Subscribe<T>(int instanceId, Action<T> listener) where T : IMessageBase
        {
            MessageHubService.Subscribe(instanceId, listener);
        }

        public static void Publish<T>(T message) where T : IMessageBase
        {
            MessageHubService.Publish(message);
        }
    }
}
