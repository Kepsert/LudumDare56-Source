﻿namespace Messaging
{
    public interface IMessageBase
    {
        
    }

}
