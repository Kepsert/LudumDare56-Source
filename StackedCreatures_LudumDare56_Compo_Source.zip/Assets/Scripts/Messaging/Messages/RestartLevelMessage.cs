namespace Messaging.Messages
{
    public class RestartLevelMessage : IMessageBase
    {
        public RestartLevelMessage()
        {

        }
    }
}