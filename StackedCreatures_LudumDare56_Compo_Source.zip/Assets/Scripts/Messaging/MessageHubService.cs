﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Messaging
{
    public class MessageHubService : IMessageHub
    {
        private readonly Dictionary<Type, List<MessageClass>> _registeredListeners =
            new Dictionary<Type, List<MessageClass>>( );
        

        public void ClearListeners()
        {
            _registeredListeners.Clear();
        }

        public void Unsubscribe<T>(Object token) where T : IMessageBase
        {
            var type = typeof( T );
            if (_registeredListeners.TryGetValue(type, out var listener))
            {
                listener.RemoveAll(x => x.Token == token.GetInstanceID());
            }
        }
        
        public void Unsubscribe<T>(int instanceId) where T : IMessageBase
        {
            var type = typeof( T );
            if (_registeredListeners.TryGetValue(type, out var listener))
            {
                listener.RemoveAll(x => x.Token == instanceId);
            }
        }

        public void Subscribe<T>( Object monoBehaviour, Action<T> listener ) where T : IMessageBase
        {
            Subscribe(monoBehaviour.GetInstanceID(), listener);
        }

        public void Subscribe<T>(int instanceId, Action<T> listener) where T : IMessageBase
        {
            var type = typeof( T );
            if( !_registeredListeners.ContainsKey( type ) )
            {
                _registeredListeners.Add( type, new List<MessageClass>() );
            }

            var messageClass = new MessageClass(m => listener((T)m), instanceId);
            _registeredListeners[type].Add(messageClass);

        }

        public void Publish<T>( T message ) where T : IMessageBase
        {
            PublishInternal( message );
        }
        

        private void PublishInternal<T>(T message ) where T : IMessageBase
        {
            var type = message.GetType();
            if( _registeredListeners.TryGetValue(type, out var listener) )
            {
                for (var i = listener.Count - 1; i >= 0; i--)
                {
                    var kv = listener[i];
                    try
                    {
                        kv.Message.Invoke(message);
                    }
                    catch (Exception e)
                    {
                        // Debug.LogError($"{e}\n\n{e.StackTrace}");
                        throw;
                    }
                }
            }
        }
    }
}