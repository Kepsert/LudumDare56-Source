﻿using System;
using System.Threading.Tasks;
using Object = UnityEngine.Object;

namespace Messaging
{
    public interface IMessageHub
    {
        void ClearListeners();
        void Unsubscribe<T>(Object token) where T : IMessageBase;
        void Unsubscribe<T>(int instanceId) where T : IMessageBase;
        void Subscribe<T>(Object monoBehaviour, Action<T> listener) where T : IMessageBase;
        void Subscribe<T>(int instanceId, Action<T> listener) where T : IMessageBase;
        void Publish<T>(T message) where T : IMessageBase;
        
    }
}